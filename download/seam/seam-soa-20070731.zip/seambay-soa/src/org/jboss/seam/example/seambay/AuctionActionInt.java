package org.jboss.seam.example.seambay;

import static org.jboss.seam.ScopeType.CONVERSATION;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.List;

import javax.persistence.EntityManager;

import org.jboss.seam.annotations.Begin;
import org.jboss.seam.annotations.Conversational;
import org.jboss.seam.annotations.End;
import org.jboss.seam.annotations.In;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;
import org.jboss.seam.annotations.security.Restrict;
import org.jboss.seam.faces.FacesMessages;

/**
 * This component is used to create new auctions, and is invoked via both the
 * web interface and the AuctionService web service. 
 *  
 * @author Shane Bryzak
 */
public interface AuctionActionInt
{
   public void createAuction();
   
   public void setDetails(String title, String description, int categoryId);
   
   /**
    * Allows the auction duration to be overidden from the default
    * 
    * @param days Number of days to set the auction duration to.
    */
   public void setDuration(int days);
   
   public int getDuration();
   
   public void uploadImage();
   
   public void confirm();

   public Auction getAuction();
   
   public void setAuction(Auction auction);
   
   public Integer getCategoryId();
   
   public void setCategoryId(Integer categoryId);
   
   public void setImageData(byte[] imageData);
   
   public void setImageContentType(String contentType);
   
   public void setPrimaryImage(boolean primary);
   
   public List<AuctionImage> getImages();

   public void destroy(); 
}
