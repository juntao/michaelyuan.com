package splice;

import java.io.StringReader;
import java.util.Collection;
import java.util.Iterator;

import org.dom4j.Attribute;
import org.dom4j.Document;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;

public class XmlSerializer
{

	public static Document toDocument(Object object, String template)
		throws Exception
	{
		return toDocument( object, new SAXReader().read(new StringReader(template)) );
	}

	public static Document toDocument(Object object, Document template)
		throws Exception
	{
		return DocumentHelper.createDocument( toElement(object, template.getRootElement()) );
	}

	public static Element toElement(Object object, Element template)
		throws Exception
	{
		Element element = null;
		if (object != null)
		{
			Class<?> clazz = object.getClass();
			element = DocumentHelper.createElement( clazz.getSimpleName() );
			for (Iterator<?> iter = template.attributeIterator(); iter.hasNext();)
			{
				Attribute attr = (Attribute)iter.next();
				String name = attr.getName();
				Object prop = getProperty(object, name);
				if (prop != null)
					element.addAttribute( name, String.valueOf(prop) );
			}
			for (Iterator<?> iter = template.elementIterator(); iter.hasNext();)
			{
				Element elem = (Element)iter.next();
				String name = elem.getName();
				Object prop = getProperty(object, name);
				if (prop != null)
				{
					Class<?> prop_clazz = prop.getClass();
					// TODO: doesn't handle "prop_clazz.isArray()"
					if ( Collection.class.isAssignableFrom(prop_clazz) )
					{
						Element wrap = DocumentHelper.createElement(name);
						for (Object o : (Collection)prop)
						{
							if (o != null)
							{
								Element e = toElement( o, elem.element(o.getClass().getSimpleName()) );
								if (e != null)
									wrap.add(e);
							}
						}
						element.add(wrap);
					}
					else
						element.add( toElement(prop, elem) );
				}
			}
		}
		return element;
	}
	
	private static Object getProperty(Object object, String prop_name)
		throws Exception
	{
		// TODO: doesn't handle "is"
		String getter = "get" +
			String.valueOf( prop_name.charAt(0) ).toUpperCase() +
			prop_name.substring( 1, prop_name.length() );
		return object.getClass().getMethod(getter, (Class[])null).invoke(object, (Object[])null);
	}

	

	public static final String TEMPLATE =
		"<Auction auctionId=\"\" title=\"\" description=\"\" endDate=\"\" price=\"\">" +
			"<Account accountId=\"\" name=\"\">" +
			"</Account>" +
			"<Category categoryId=\"\" name=\"\">" +
			"</Category>" +
		"</Auction>";

}
