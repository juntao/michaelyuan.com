package splice;

import org.jboss.seam.example.seambay.*;
import javax.ejb.*;
import javax.interceptor.*;

import org.dom4j.Document;
import org.dom4j.io.OutputFormat;
import org.dom4j.io.XMLWriter;
import java.io.StringWriter;

public class AuctionInterceptor {

  @AroundInvoke
  public Object sendAuctionToESB (InvocationContext ctx) throws Exception {

    System.out.println("*** Entering AuctionInterceptor");

    Object target = ctx.getTarget ();
    if (target instanceof AuctionAction) {
      if (ctx.getMethod().getName().equals("confirm")) {
        System.out.println("We will send the following Auction object to ESB");
        Auction auction = ((AuctionAction) target).getAuction ();
        // Send the following XML string to JMS
        formatMessage(auction);
      }
    }

    try {
      return ctx.proceed();
    } finally {
       System.out.println("*** Exiting AuctionInterceptor");
    }
  }

  private String formatMessage(Auction auction) {
                Document auctionMessage = null;
                try {
                        StringWriter sw = new StringWriter();
                        auctionMessage = XmlSerializer.toDocument(auction,
                                        XmlSerializer.TEMPLATE);
                        XMLWriter xw = new XMLWriter(sw, new OutputFormat("  ", true));
                        xw.write(auctionMessage);
                        System.out.println(sw.toString());
                        return sw.toString();
                } catch (Exception e) {
                        e.printStackTrace(System.out);
                }
                return "Failed to Serialize";
  }

}
