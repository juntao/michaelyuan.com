
import javax.ejb.*;
import javax.faces.context.FacesContext;
import org.jboss.seam.annotations.remoting.*;

@Local
public interface Manager {
  public String sayHello ();
  public String startOver ();
  public void find ();
  public String delete ();
  public void destroy ();

  @WebRemote
  public boolean checkName (String name);
  
  @WebRemote
  public void setComment (String comment);
}
