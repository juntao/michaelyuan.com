
import static org.jboss.seam.ScopeType.SESSION;
import static org.jboss.seam.annotations.Outcome.REDISPLAY;

import java.util.List;
import javax.ejb.*;
import org.jboss.seam.annotations.*;
import org.jboss.seam.annotations.datamodel.*;
import org.jboss.seam.ejb.*;
import org.hibernate.validator.Valid;

import javax.persistence.*;
import javax.faces.context.FacesContext;

@Stateful
@Scope(SESSION)
@Name("manager")
public class ManagerAction implements Manager {

  @In @Out // @Valid
  private Person person;

  @PersistenceContext
  private EntityManager em;

  // @IfInvalid(outcome=REDISPLAY)
  public String sayHello () {
    em.persist (person);
    find ();
    return "fans";
  }

  public String startOver () {
    System.out.println("startover called");
    person = new Person ();
    return "hello";
  }

  @DataModel
  private List <Person> fans;

  @DataModelSelection
  private Person selectedFan;

  @Factory("fans")
  public void find () {
    System.out.println("Find called");
    fans = em.createQuery("select p from Person p")
                                  .getResultList();
  }

  public String delete () {
    Person deleted = em.find(Person.class,
                         selectedFan.getId());
    if (deleted!=null) em.remove( deleted );
    find ();
    // greeter = new Greeter ();
    return null;
  }

  @Remove @Destroy
  public void destroy() {}

  public boolean checkName (String name) {
    System.out.println("CheckName() is called");
    
    List <Person> existing = em.createQuery(
        "select p from Person p where name=:name")
        .setParameter("name", name)
        .getResultList();
    
    if (existing.size() != 0) {
      return false;
    } else {
      return true;
    }
  }
  
  public void setComment (String comment) {
    System.out.println("setComment() is called with " + comment);
    person.setComment (comment);
  }

}
