The default targets builds a Seam POJO app with JPA for JBoss AS 4.2.0 GA.

If you want to build for JBoss AS 4.0.5 GA, use the "ant war405" task
