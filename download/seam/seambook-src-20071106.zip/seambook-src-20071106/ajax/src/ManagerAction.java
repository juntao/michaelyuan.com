import static org.jboss.seam.annotations.Outcome.REDISPLAY;

import java.util.*;
import javax.ejb.*;
import org.jboss.seam.annotations.*;
import org.jboss.seam.annotations.datamodel.*;
import org.jboss.seam.annotations.web.*;
import org.jboss.seam.ejb.*;
import org.hibernate.validator.Valid;
import javax.faces.event.ValueChangeEvent;
import javax.faces.model.SelectItem;
import com.icesoft.faces.component.selectinputtext.SelectInputText;

import javax.persistence.*;

import static javax.persistence.PersistenceContextType.EXTENDED;

@Stateful
@Name("manager")
public class ManagerAction implements Manager {

  @In (required=false) @Out (required=false)
  private Person person;

  @PersistenceContext (type=EXTENDED)
  private EntityManager em;

  @RequestParameter
  Long pid;

  public String sayHello () {
    em.persist (person);
    // find ();
    return "fans";
  }

  // public String startOver () {
  //   System.out.println("startover called");
  //   return "hello";
  // }

  @DataModel
  private List <Person> fans;

  @DataModelSelection
  private Person selectedFan;

  @Factory("fans")
  public void findFans () {
    System.out.println("Find called");
    fans = em.createQuery("select p from Person p")
                                  .getResultList();
  }

  @Factory("person")
  public void findPerson () {
    if (pid != null) {
      person = (Person) em.find(Person.class, pid);
    } else {
      person = new Person ();
    }
  }
  
  public String delete () {
    // merge? or page scope data model?
    Person toDelete = em.merge (selectedFan);
    em.remove( toDelete );
    findFans ();
    return null;
  }

  public String update () {
    System.out.println("Person ID" + person.getId());
    System.out.println("Person Name" + person.getName());

    // The "person" component is detached since this is not
    // a long running conversation
    // Person p = em.merge (person);
    // find ();
    return "fans";
  }

  String [] popularNames = new String [] {
      "Gavin King", "Thomas Heute", "Michael Yuan",
      "Norman Richards", "Bill Burke", "Marc Fleury"
  };

  ArrayList <SelectItem> nameHints;
  public List getNameHints () {
    return nameHints;
  }

  public void updateNameHints (ValueChangeEvent e) {

    String prefix = (String) e.getNewValue ();
    int maxMatches = ((SelectInputText) e.getComponent()).getRows();

    System.out.println("Number of rows " + maxMatches);
    System.out.println("Current in the field: " + prefix);

    nameHints = new ArrayList <SelectItem> ();
   
    int totalNum = 0;
    if (prefix.length() > 0) {
      for (int i=0; i<popularNames.length; i++) {
        if (popularNames[i].toLowerCase()
       .indexOf(prefix.toLowerCase())!=-1
            && totalNum < maxMatches) {

          nameHints.add(new SelectItem (i, popularNames[i]));
          totalNum++;

          System.out.println("Add " + popularNames[i]);
        }
      }
    } else {
      for (int i=0; i<maxMatches &&
                   i<popularNames.length; i++) {
        nameHints.add(new SelectItem (i, popularNames[i]));
      }
    }
  }

  @Remove @Destroy
  public void destroy() {}

}
