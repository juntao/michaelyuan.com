
import javax.ejb.*;

@Local
public interface Manager {
  
  public String sayHello ();
  
  public void find ();

  public String deleteComment ();
  public String delete ();
  
  public void setName (String name);
  public String getName ();
  
  public void setNameErrorMsg (String nameErrorMsg);
  public String getNameErrorMsg ();
  
  public void destroy();
}
