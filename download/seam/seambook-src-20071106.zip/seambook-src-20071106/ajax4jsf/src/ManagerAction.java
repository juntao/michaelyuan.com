
import java.util.List;
import javax.ejb.*;
import org.jboss.seam.annotations.*;
import org.jboss.seam.ejb.*;
import javax.persistence.*;
import org.jboss.seam.annotations.datamodel.*;

import static javax.persistence.PersistenceContextType.EXTENDED;

@Stateful
@Name("manager")
public class ManagerAction implements Manager {

  @In (required=false) @Out (required=false)
  private Person person;
 
  @DataModel
  private List <Person> fans;
  @DataModelSelection
  private Person selectedFan;

  @PersistenceContext (type=EXTENDED)
  private EntityManager em;
 
  public ManagerAction () { }
  
  public String sayHello () {
    System.out.println("The name is " + name);
    
    person.setName (name);
    em.persist (person);
    person = new Person ();
    name = "";
    find();
    return null;
  }

  @Factory("fans")
  public void find () {
    System.out.println("Find called");
    fans = em.createQuery("select p from Person p")
                                  .getResultList();
  }

  public String deleteComment () {
    System.out.println("Del comment is called here!!");
    Person p = em.merge (selectedFan);
    p.setComment ("");
    selectedFan.setComment("");
    return null;
  }
  
  public String delete () {
    System.out.println("Del is called here!!");
    Person p = em.merge (selectedFan);
    em.remove (p);
    find();
    return null;
  }
  
  String name;
  public void setName (String name) {
    System.out.println("setName() is called");
    
    this.name = name;
    
    List <Person> existing = em.createQuery(
        "select p from Person p where name=:name")
        .setParameter("name", name)
        .getResultList();
    
    if (existing.size() != 0) {
      nameErrorMsg = "Warning: \"" + name + 
          "\" is already in the system.";
    } else {
      nameErrorMsg = "";
    }
    return;
  }
  public String getName () {
    return name;
  }
  
  String nameErrorMsg;
  public void setNameErrorMsg (String nameErrorMsg) {
    this.nameErrorMsg = nameErrorMsg;
  }
  public String getNameErrorMsg () {
    return nameErrorMsg;
  }
  
  @Destroy @Remove
  public void destroy() { }
  
}
