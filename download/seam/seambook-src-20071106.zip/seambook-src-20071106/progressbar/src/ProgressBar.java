import javax.ejb.Local;

import org.jboss.seam.annotations.remoting.WebRemote;

@Local
public interface ProgressBar {
  String doSomething();
  @WebRemote Progress getProgress();
}

