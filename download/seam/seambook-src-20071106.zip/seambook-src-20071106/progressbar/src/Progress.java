import org.jboss.seam.ScopeType;
import org.jboss.seam.annotations.Name;
import org.jboss.seam.annotations.Scope;

@Name("progress")
@Scope(ScopeType.SESSION)
public class Progress {

  private int percentComplete;

  public int getPercentComplete()
  {
    return percentComplete;
  }

  public void setPercentComplete(int percentComplete)
  {
    this.percentComplete = percentComplete;
  }

}
