
import javax.ejb.*;

@Local
public interface Manager {
  public String sayHello (Person p);
}
