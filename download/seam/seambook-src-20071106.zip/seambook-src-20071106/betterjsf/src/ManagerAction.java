
import java.util.List;
import javax.ejb.*;
import org.jboss.seam.annotations.*;
import org.jboss.seam.ejb.*;
import javax.persistence.*;

@Stateless
@Name("manager")
public class ManagerAction implements Manager {

  @Out
  private Person person;
 
  @Out
  private List <Person> fans;

  @PersistenceContext
  private EntityManager em;
 
  public String sayHello (Person p) {
    person = p;
    em.persist (person);
    person = new Person ();
    fans = em.createQuery("select p from Person p")
             .getResultList();
    return null;
  }

}
