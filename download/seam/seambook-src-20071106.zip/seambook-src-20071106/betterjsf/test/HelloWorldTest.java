import org.jboss.seam.Component;
import org.jboss.seam.mock.SeamTest;
import java.util.*;
import org.testng.annotations.Test;
import javax.persistence.*;

public class HelloWorldTest extends SeamTest {
   
  @Test
  public void testSayHello() throws Exception {

    new FacesRequest("/hello.xhtml") {

      @Override
      protected void updateModelValues() throws Exception {
        setValue("#{person.name}", "Michael Yuan");
      }

      @Override
      protected void invokeApplication() {
        assert getValue ("#{person.name}").equals("Michael Yuan");
        assert invokeMethod("#{manager.sayHello(person)}") == null;
        assert getValue ("#{person.name}") == null;
      }

      @Override
      protected void renderResponse() {
        List<Person> fans = 
            (List<Person>) getValue("#{fans}");
        assert fans!=null;
        assert fans.get(fans.size()-1)
                   .getName().equals("Michael Yuan");
      }

    }.run();
      
  }
  
  @Test
  public void unitTestSayHello() throws Exception {

    Manager manager = new ManagerAction ();

    EntityManagerFactory emf = 
      Persistence.createEntityManagerFactory("helloworld");
    EntityManager em = emf.createEntityManager();
    setField(manager, "em", em);

    Person person = new Person ();
    person.setName ("Thomas Heute");
    setField(manager, "person", person);

    // getUserTransaction().begin();
    em.getTransaction().begin();
    manager.sayHello (person);
    em.getTransaction().commit();
    // getUserTransaction().commit();

    List <Person> fans = 
        (List<Person>) getField (manager, "fans");
    assert fans!=null;
    assert fans.get(fans.size()-1)
               .getName().equals("Thomas Heute");

    person = (Person) getField (manager, "person");
    assert person != null;
    assert person.getName() == null;

    em.close();
  }
   
}
