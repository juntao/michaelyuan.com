import javax.ejb.*;
import org.jboss.seam.annotations.exception.Redirect;

@ApplicationException(rollback=true)
@Redirect(viewId="/inventoryError.xhtml")
public class InventoryException extends Exception {

  public InventoryException () { }

}
