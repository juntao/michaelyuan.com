import javax.ejb.Local;

@Local
public interface Login
{
   public boolean login();
}
