
NOTE: You have to first install the Nokia Series 40 Developer Platform 2.0
SDK in its default directory "C:/Nokia/Devices" before you run the
default build scripts. If you use Linux or choose other SDK installation
directories, you have to modify the "build.xml" file for each project.

This file lists all the sample applications for this book. In each
application directory, there is a "build.bat" script to
build the application on Windows platform and a "build.sh" script
to build the application on Linux/Unix platform.

The JAR and JAD files for the MIDlets are stored in the "bin" directory.
The ready-to-deploy server applications are in the "deploy" directory.

* chapter03/PhotoViewerBasic: The basic photo viewer

* chapter04/BasicUI: Demonstrate the MIDP 2 UI

* chapter05/FishDemo: A simple animated fish

* chapter05/FishGame: The animated fish game

* chapter06/PhotoViewerComments: A photo viewer with comments

* chapter07/PhotoViewerNetwork: A network-based photo viewer
  + MIDP: The MIDlet running on the mobile phone
  + Server: The Java servlet component to serve photo images

* chapter08/Chat: Mobile chat via SMS

* chapter09/MediaPlayer: Playback multimedia files

* chapter09/MidiPlayer: Control and playback midi files

* chapter09/MultimediaBlog: Multimedia blog with photo and audio
  + MIDP: The MIDlet running on a Series 60 mobile phone
  + Server: The Java servlet component to receive and publish the blog entries

* chapter10/BTDiscovery: Discover and browse Bluetooth services in the network

* chapter10/Bluetooth: Bluetooth based serial communication between devices

* chapter11-13/Trivia: The mobile trivia game
  + MIDP: The MIDlet client running on the mobile phone
  + Server: The Java servlet to serve the trivia questions and store scores

* chapter14/SMIL: Examples of SMIL files for MMS
