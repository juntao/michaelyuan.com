package com.Series40Book;

import javax.microedition.lcdui.*;


public class ListSlides extends List
          implements CommandListener {

  private Command go;
  private Command search;

  public ListSlides (String [] titles) {
    super ("List", Choice.IMPLICIT, titles, null);

    go = new Command ("Go", Command.OK, 1);
    search = new Command ("Search", Command.SCREEN, 1);
    addCommand (go);
    addCommand (search);
    setCommandListener (this);

    // For MIDP v2 only
    // setSelectCommand (go);
  }

  public void commandAction (Command c, Displayable d) {
    if (c == go || c == SELECT_COMMAND) {
      try {
        PhotoViewer.jumpTo (getSelectedIndex ());
      } catch (Exception e) {
        e.printStackTrace ();
      }
    } else if (c == search) {
      PhotoViewer.showSearch ();
    }
  }
}