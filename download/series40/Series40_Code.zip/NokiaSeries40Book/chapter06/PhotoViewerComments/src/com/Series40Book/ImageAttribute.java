package com.Series40Book;

import java.io.*;

public class ImageAttribute {
  public String fileName;
  public String title;
  public String comment;
  public int rating;
  public boolean showComment;

  public ImageAttribute (String fileName) {
    this.fileName = fileName;
    title = " ";
    comment = " ";
    rating = 3;
    showComment = true;
  }

  protected ImageAttribute () { }

  public byte [] serialize () throws Exception {
    ByteArrayOutputStream bos =
              new ByteArrayOutputStream ();
    DataOutputStream dbos = new DataOutputStream (bos);
    dbos.writeUTF (fileName);
    dbos.writeUTF (title);
    dbos.writeUTF (comment);
    dbos.writeInt (rating);
    dbos.writeBoolean (showComment);
    return bos.toByteArray ();
  }

  public static ImageAttribute deserialize (
                  byte [] record) throws Exception {
    ImageAttribute attr = new ImageAttribute ();

    ByteArrayInputStream bis =
              new ByteArrayInputStream (record);
    DataInputStream dbis = new DataInputStream (bis);

    attr.fileName = dbis.readUTF ();
    attr.title = dbis.readUTF ();
    attr.comment = dbis.readUTF ();
    attr.rating = dbis.readInt ();
    attr.showComment = dbis.readBoolean ();
    return attr;
  }

}