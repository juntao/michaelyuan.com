package com.Series40Book;

import javax.microedition.rms.*;

public class RatingComparator
        implements RecordComparator {

  public RatingComparator () { }

  public int compare (byte [] r1, byte [] r2) {
    ImageAttribute attr1, attr2;

    try {
      attr1 = ImageAttribute.deserialize (r1);
      attr2 = ImageAttribute.deserialize (r2);
    } catch (Exception e) {
      e.printStackTrace ();
      return EQUIVALENT;
    }

    if (attr1.rating > attr2.rating) {
      return PRECEDES;
    } else if (attr1.rating < attr2.rating) {
      return FOLLOWS;
    } else {
      return EQUIVALENT;
    }
  }
}