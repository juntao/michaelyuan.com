package com.Series40Book;

import javax.microedition.lcdui.*;


public class Search extends Form
          implements CommandListener {

  private Command ok;
  private TextField catField;

  public Search () {
    super ("Search");
    ok = new Command ("Go", Command.OK, 1);
    addCommand (ok);
    setCommandListener (this);

    catField = new TextField ("Search for", "",
                              20, TextField.ANY);
    append ("Please enter a search string");
    append (catField);
  }

  public void commandAction (Command c, Displayable d) {
    if (c == ok) {
      PhotoViewer.doSearch(catField.getString());
    }
  }
}