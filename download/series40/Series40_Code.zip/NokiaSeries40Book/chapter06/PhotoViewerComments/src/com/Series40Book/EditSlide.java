package com.Series40Book;

import javax.microedition.lcdui.*;


public class EditSlide extends Form
          implements CommandListener {

  private Command ok;
  private Command cancel;
  private TextField commentField;
  private Gauge ratingGauge;
  private ChoiceGroup cg;

  public EditSlide (String comment, int rating) {
    super ("Edit");
    ok = new Command ("OK", Command.OK, 1);
    cancel = new Command ("Cancel", Command.CANCEL, 1);
    addCommand (ok);
    addCommand (cancel);
    setCommandListener (this);

    commentField = new TextField ("Comment", comment,
                                  50, TextField.ANY);
    ratingGauge = new Gauge("rating", true, 10, rating);
    cg = new ChoiceGroup("Show Comments?",
                         Choice.EXCLUSIVE);
    cg.append ("Yes", null);
    cg.append ("No", null);

    append (commentField);
    append (ratingGauge);
    append (cg);
  }

  public void commandAction (Command c, Displayable d) {
    if (c == ok) {
      boolean showComment;
      if (cg.getSelectedIndex() == 0) {
        showComment = true;
      } else {
        showComment = false;
      }
      PhotoViewer.doEdit(commentField.getString(),
                        ratingGauge.getValue(),
                        showComment);
    } else if (c == cancel) {
      PhotoViewer.showSlide ();
    }
  }
}
