package com.Series40Book;

import javax.microedition.lcdui.*;


public class ShowSlide extends Form
          implements CommandListener {

  private Command edit;
  private Command search;
  private Command list;
  private Command next;

  public ShowSlide (Image img, String title,
                    String comment, int rating) {
    super ("slide");
    edit = new Command ("Edit", Command.OK, 1);
    search = new Command ("Search", Command.SCREEN, 1);
    list = new Command ("List", Command.SCREEN, 1);
    next = new Command ("Next", Command.SCREEN, 1);
    addCommand (edit);
    addCommand (search);
    addCommand (list);
    addCommand (next);
    setCommandListener (this);

    append (new ImageItem(title, img,
                      ImageItem.LAYOUT_CENTER, title));
    append (new StringItem("Comment", comment));
    append (new Gauge("rating", false, 10, rating));
  }

  public ShowSlide (Image img, String title) {
    super ("slide");
    edit = new Command ("Edit", Command.OK, 1);
    search = new Command ("Search", Command.SCREEN, 1);
    list = new Command ("List", Command.SCREEN, 1);
    next = new Command ("Next", Command.SCREEN, 1);
    addCommand (edit);
    addCommand (search);
    addCommand (list);
    addCommand (next);
    setCommandListener (this);

    append (new ImageItem(title, img,
                      ImageItem.LAYOUT_CENTER, title));
  }


  public void commandAction (Command c, Displayable d) {
    if (c == edit) {
      PhotoViewer.showEdit ();
    } else if (c == search) {
      PhotoViewer.showSearch ();
    } else if (c == list) {
      PhotoViewer.backtoList ();
    } else if (c == next) {
      try {
        PhotoViewer.next ();
      } catch (Exception e) {
        e.printStackTrace();
      }
    }
  }
}