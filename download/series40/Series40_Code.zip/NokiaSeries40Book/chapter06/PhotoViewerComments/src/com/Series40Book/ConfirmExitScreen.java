package com.Series40Book;

import javax.microedition.lcdui.*;

public class ConfirmExitScreen extends Form
                  implements CommandListener {

  private PhotoViewer viewer;
  private Command yesButton;
  private Command noButton;

  public ConfirmExitScreen (PhotoViewer v) {
    super ("Confirm");
    viewer = v;

    yesButton = new Command ("Yes", Command.OK, 1);
    noButton = new Command ("No", Command.BACK, 1);

    append ("Really exit?");
    addCommand (yesButton);
    addCommand (noButton);
    setCommandListener (this);
  }


  public void commandAction (Command c, Displayable d) {
    if ( c == yesButton ) {
      viewer.exitConfirmed = true;
      viewer.safeShutdown ();
    } else {
      viewer.exitConfirmed = false;
      viewer.showList ();
    }
  }

}