package com.Series40Book;

import javax.microedition.rms.*;


public class SearchFilter implements RecordFilter {

  private String searchStr;

  public SearchFilter (String s) {
    searchStr = s;
  }

  public boolean matches (byte [] record) {
    ImageAttribute attr;

    try {
      attr = ImageAttribute.deserialize (record);
    } catch (Exception e) {
      e.printStackTrace ();
      return false;
    }

    if (attr.comment.indexOf (searchStr) != -1 ||
        attr.title.indexOf (searchStr) != -1) {
      return true;
    } else {
      return false;
    }
  }

}