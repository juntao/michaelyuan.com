import javax.microedition.lcdui.*;
import javax.microedition.lcdui.game.*;
import java.util.*;

public class Star extends Sprite {
	private static final String IMAGE_FILENAME = "/starsprite.png";
	private static final int IMAGE_COLUMNS = 3;
	private static final int IMAGE_ROWS = 1;

	private int m_fallY;

	private static Image m_image;
	private static final Image getImage() {
		try {
			m_image = Image.createImage(IMAGE_FILENAME);
		}
		catch (Exception e) {
			System.err.println("Error loading star image");
			return null;
		}
		return m_image;
	}

	public Star(Random rand, int screenwidth, int y) {
		super(getImage(),
			  m_image.getWidth() / IMAGE_COLUMNS,
			  m_image.getHeight() / IMAGE_ROWS);

		if (Math.abs(rand.nextInt()) % 3 == 0) {
			m_fallY = 2;
		}
		else {
			m_fallY = 1;
		}
		int x = Math.abs(rand.nextInt()) % (screenwidth - getWidth());
		setPosition(x, y);
	}

	public void fall() {
		move(0, m_fallY);
		nextFrame();
	}
}
