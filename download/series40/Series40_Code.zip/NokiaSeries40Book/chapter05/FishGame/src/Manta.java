import javax.microedition.lcdui.*;
import javax.microedition.lcdui.game.*;

public class Manta extends Sprite {
	public static final int LEFT = 1;
	public static final int RIGHT = 2;

	private static final String IMAGE_FILENAME = "/mantasprite.png";
	private static final int IMAGE_COLUMNS = 4;
	private static final int IMAGE_ROWS = 1;
	private static final int m_anim[] = {0,0,1,1,2,2,3,3};

	private static final int MANTA_MOVE = 2;

	public int m_direction;
	private int m_moveX;
	private int m_minX, m_maxX;

	private static Image m_image;
	private static final Image getImage() {
		try {
			m_image = Image.createImage(IMAGE_FILENAME);
		}
		catch (Exception e) {
			System.err.println("Error loading manta image");
			return null;
		}
		return m_image;
	}

    public Manta(int screenwidth) {
		super(getImage(),
			  m_image.getWidth() / IMAGE_COLUMNS,
			  m_image.getHeight() / IMAGE_ROWS);

		m_minX = 0 - getWidth();
		m_maxX = screenwidth;

		setVisible(false);
		defineReferencePixel(getWidth()/2, getHeight()/2);
		setFrameSequence(m_anim);
	}

	public void init(int x, int y, int direction) {
		setPosition(x, y);
		m_direction = direction;

		if (direction == RIGHT) {
			setTransform(TRANS_NONE);
			m_moveX = MANTA_MOVE;
		}
		else {
			setTransform(TRANS_MIRROR);
			m_moveX = -MANTA_MOVE;
		}

		setVisible(true);
    }
	public void swim() {
		nextFrame();
		move(m_moveX, 0);
		int x = getX();
		if (x < m_minX || x > m_maxX) {
			setVisible(false);
		}
	}
}
