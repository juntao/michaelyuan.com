import javax.microedition.lcdui.*;

public class Fish {
	private static final String FISH_IMAGE = "/fishy.png";

	public static final int UP = 1;
	public static final int DOWN = 2;
	public static final int LEFT = 3;
	public static final int RIGHT = 4;

	public int m_x, m_y;
	public int m_dx, m_dy;
	public int m_moveX, m_moveY;

	public int m_width, m_height;
	private Image m_fishImage;


	public Fish(int x, int y) {
		try {
			m_fishImage = Image.createImage(FISH_IMAGE);
		}
		catch (Exception e) {
			System.err.println("Error loading image " + FISH_IMAGE);
			return;
		}
		//store size for collision rectangle
		m_width = m_fishImage.getWidth();
		m_height = m_fishImage.getHeight();
		//set fish movement
		m_moveX = m_width / 4;
		m_moveY = m_height / 4;
		//center fish on screen center
		m_x = x - m_width/2;
		m_y = y - m_height/2;
	}

	public boolean start() {
		if (m_fishImage == null) {
			System.err.println("Can't start");
			return false;
		}
		return true;
	}

	public void paint(Graphics g) {
		if (m_fishImage != null) {
			g.drawImage(m_fishImage,
						m_x, m_y,
						Graphics.TOP | Graphics.LEFT);
		}
	}
	public void swim(int direction) {
		switch (direction) {
			case UP:    m_dy = -m_moveY; break;
			case DOWN:  m_dy = m_moveY; break;
			case LEFT:  m_dx = -m_moveX; break;
			case RIGHT: m_dx = m_moveX; break;
		}
	}
	public void finishMove() {
		m_x += m_dx;
		m_y += m_dy;
		m_dx = 0;
		m_dy = 0;
	}
}
