public class Obstacle {
	public int m_x, m_y;
	public int m_width, m_height;

	public Obstacle(int x, int y, int width, int height) {
		m_x = x;
		m_y = y;
		m_width = width;
		m_height = height;
    }
}