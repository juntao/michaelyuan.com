import javax.microedition.lcdui.*;
import javax.microedition.midlet.*;

/**
 * <p>Title: FishMidlet</p>
 * <p>Description: Chapter 5 example of interactive animation</p>
 * <p>Copyright: Copyright (c) 2004</p>
 * @tpark
 * @version 1.0
 */

public class FishMidlet extends MIDlet implements CommandListener {
	private static Display m_display;
	private static FishCanvas m_canvas;
	private static FishMidlet m_midlet;

	public FishMidlet() {
		m_canvas = new FishCanvas();
	}

	//singleton getInstance
	public static FishMidlet getMidlet() {
		return m_midlet;
	}

	protected void startApp() throws MIDletStateChangeException {
		m_midlet = this; //save for getMidlet()
		if (m_display == null) {
			m_display = Display.getDisplay(this);
			m_display.setCurrent(m_canvas);
		}
		m_canvas.start();
	}

	protected void pauseApp() {
		m_canvas.stop();
	}

	protected void destroyApp(boolean flag) throws MIDletStateChangeException {
		m_canvas.exit();
	}


	//--------------------------------------------------------------------------
	// Game Command handling
	//--------------------------------------------------------------------------
	private Command m_cmdExit = new Command ("Exit", Command.EXIT, 1);
	private Command m_cmdPause = new Command ("Pause", Command.OK, 2);
	private Command m_cmdPlay = new Command ("Play", Command.OK, 2);

	//CommandListener
	public void commandAction (Command cmd, Displayable d) {
		if (cmd == m_cmdExit) {
			try {
				m_midlet.destroyApp(true);
			}
			catch (Exception e) {
			}
			m_midlet.notifyDestroyed();
		}
		else if (cmd == m_cmdPause) {
			m_canvas.removeCommand(m_cmdPause);
			m_canvas.addCommand(m_cmdPlay);
			m_canvas.isPaused = true;
		}
		else if (cmd == m_cmdPlay) {
			m_canvas.removeCommand(m_cmdPlay);
			m_canvas.addCommand(m_cmdPause);
			m_canvas.isPaused = false;
		}
	}

}