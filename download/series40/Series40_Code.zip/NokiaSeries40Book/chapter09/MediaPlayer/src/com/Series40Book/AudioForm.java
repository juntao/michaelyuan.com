package com.Series40Book;

import javax.microedition.lcdui.*;

public class AudioForm extends Form
              implements CommandListener {

  private Command done;

  public AudioForm () {
    super ("Play audio");
    done = new Command ("Done", Command.OK, 1);
    addCommand (done);
    setCommandListener (this);

    append (new StringItem ("","The Music is playing"));
  }

  public void commandAction (Command c, Displayable d) {
    if (c == done) {
      MediaPlayer.stopPlayer ();
      MediaPlayer.showMenu ();
    }
  }
}
