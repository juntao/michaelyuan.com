package com.Series40Book;

import javax.microedition.lcdui.*;
import javax.microedition.media.*;
import javax.microedition.media.control.VideoControl;
import javax.microedition.media.control.GUIControl;

public class VideoForm extends Form
         implements CommandListener {

  private Player player;
  private Command done;

  public VideoForm () {
    super ("Play video");
    done = new Command("Done", Command.OK, 1);
    addCommand (done);
    setCommandListener (this);
  }

  public void startPlayer (Player p) {
    player = p;
    try {
      // Add the video playback window (item)
      VideoControl video =
        (VideoControl) player.getControl("VideoControl");
      Item item = (Item) video.initDisplayMode(
          GUIControl.USE_GUI_PRIMITIVE, null);
      item.setLayout(Item.LAYOUT_CENTER |
                     Item.LAYOUT_NEWLINE_AFTER);
      append(item);
      // Add a caption
      StringItem s = new StringItem ("", "Video");
      s.setLayout(Item.LAYOUT_CENTER);
      append (s);

      player.start();

    } catch (Exception e) {
      e.printStackTrace();
      append ("An error has occurred");
    }
  }

  public void commandAction(Command c, Displayable s) {
    if (c == done) {
      MediaPlayer.stopPlayer ();
      MediaPlayer.showMenu ();
    }
  }
}
