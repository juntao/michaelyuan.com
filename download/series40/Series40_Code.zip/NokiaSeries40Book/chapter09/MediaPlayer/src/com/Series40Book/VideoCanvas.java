package com.Series40Book;

import javax.microedition.lcdui.*;
import javax.microedition.media.*;
import javax.microedition.media.control.VideoControl;

public class VideoCanvas extends Canvas
             implements CommandListener {

  private Player player;
  private int width, height;
  private Command done;

  public VideoCanvas () {
    width = getWidth();
    height = getHeight();
    done = new Command("Done", Command.OK, 1);
    addCommand (done);
    setCommandListener (this);
  }

  public void startPlayer (Player p) {
    player = p;

    try {
      VideoControl video =
    (VideoControl) player.getControl("VideoControl");
      video.initDisplayMode(
        VideoControl.USE_DIRECT_VIDEO, this);

      video.setDisplayLocation(2, 2);
      video.setDisplaySize(width - 4, height - 4);

      player.start ();

    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  public void paint(Graphics g) {

    // Draw a green border around the VideoControl.
    g.setColor(0x00ff00);
    g.drawRect(0, 0, width - 1, height - 1);
    g.drawRect(1, 1, width - 3, height - 3);
  }

  public void commandAction(Command c, Displayable s) {
    if (c == done) {
      MediaPlayer.stopPlayer ();
      MediaPlayer.showMenu ();
    }
  }
}
