package com.Series40Book;

import javax.microedition.lcdui.*;
import javax.microedition.media.Manager;

public class PropertiesForm extends Form
            implements CommandListener {

  private Command done;

  public PropertiesForm () {
    super ("Media Properties");

    done = new Command ("Done", Command.OK, 1);
    addCommand (done);
    setCommandListener (this);

    String name;

    name = "supports.mixing";
    append (new StringItem (name,
        System.getProperty (name)));

    name = "supports.audio.capture";
    append (new StringItem (name,
        System.getProperty (name)));

    name = "supports.video.capture";
    append (new StringItem (name,
        System.getProperty (name)));

    name = "supports.recording";
    append (new StringItem (name,
        System.getProperty (name)));

    name = "audio.encodings";
    append (new StringItem (name,
        System.getProperty (name)));

    name = "video.encodings";
    append (new StringItem (name,
        System.getProperty (name)));

    name = "video.snapshot.encodings";
    append (new StringItem (name,
        System.getProperty (name)));

    name = "microedition.media.version";
    append (new StringItem (name,
        System.getProperty (name)));

    name = "streamable.contents";
    append (new StringItem (name,
        System.getProperty (name)));

    String [] tmp =
        Manager.getSupportedContentTypes("http");
    StringBuffer sb = new StringBuffer ();
    for (int i = 0; i < tmp.length; i++) {
      sb.append(tmp[i] + " ");
    }
    append (new StringItem ("Supported HTTP types",
        sb.toString()));
  }

  public void commandAction (Command c, Displayable d) {
    if (c == done) {
      MediaPlayer.showMenu ();
    }
  }

}