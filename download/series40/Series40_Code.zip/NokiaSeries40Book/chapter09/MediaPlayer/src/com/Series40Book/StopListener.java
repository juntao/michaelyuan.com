package com.Series40Book;

import javax.microedition.media.*;


public class StopListener implements PlayerListener {

  public void playerUpdate (Player player,
                 String event, Object eventData) {
    try {
      if (event.equals (STOPPED) ||
          event.equals (STOPPED_AT_TIME) ||
          event.equals (ERROR) ||
          event.equals (END_OF_MEDIA)) {

        player.stop();
        player.deallocate();
        player = null;

System.out.println(event);
      }
    } catch (Exception e) {
      e.printStackTrace ();
    }
  }

}
