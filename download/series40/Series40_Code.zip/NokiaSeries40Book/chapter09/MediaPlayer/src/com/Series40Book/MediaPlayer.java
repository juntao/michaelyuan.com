package com.Series40Book;

import javax.microedition.midlet.MIDlet;
import javax.microedition.lcdui.*;
import javax.microedition.media.*;
import java.io.InputStream;

public class MediaPlayer extends MIDlet
              implements CommandListener {

  static Display display;
  static List menu;
  static Player player;
  private WaitScreen wait;

  private Command exit;
  private Command select;

  // media file names
  public String mediaMidi;
  public String media3gpp;
  public String mediaWav;

  // media file locations
  public String remotePrefix;
  public String localPrefix;

  public MediaPlayer () {
    display = Display.getDisplay(this);

    mediaMidi = getAppProperty ("MediaMidi");
    media3gpp = getAppProperty ("Media3gpp");
    mediaWav = getAppProperty ("MediaWav");
    remotePrefix = getAppProperty ("RemotePrefix");
    localPrefix = getAppProperty ("LocalPrefix");

    exit = new Command("Exit", Command.EXIT, 1);
    select = new Command("Choose", Command.OK, 1);

    wait = new WaitScreen ();
  }

  protected void startApp () {
    menu = new List ("Select an Action", List.IMPLICIT);
    menu.append ("System properties", null);
    menu.append ("Play local MIDI", null);
    menu.append ("Play remote MIDI", null);
    menu.append ("Play local Wav", null);
    menu.append ("Play remote Wav", null);
    menu.append ("Play local 3GPP", null);
    menu.append ("Play remote 3GPP", null);

    menu.addCommand(exit);
    menu.addCommand(select);
    menu.setCommandListener(this);

    display.setCurrent (menu);
  }

  protected void pauseApp () {
    // Do nothing
  }

  protected void destroyApp (boolean unconditional) {
    // Do nothing
  }

  public void showProperties () {
    Form form = new PropertiesForm ();
    display.setCurrent (form);
  }

  public static void stopPlayer () {
    try {
      player.stop ();
    } catch (Exception e) {
      e.printStackTrace ();
    }
  }

  public static void showMenu () {
    display.setCurrent (menu);
  }

  public void commandAction(Command c, Displayable s) {
    try {
      if (c == exit) {
        destroyApp (true);
        notifyDestroyed ();

      } else if (c == select) {
        if (menu.getSelectedIndex() == 0) {
          showProperties ();

        } else if (menu.getSelectedIndex() == 1) {
          display.setCurrent (wait);
          String url = localPrefix + mediaMidi;
          String mime = "audio/midi";
          Thread t = new AudioPlayer(true, url, mime);
          t.start ();

        } else if (menu.getSelectedIndex() == 2) {
          display.setCurrent (wait);
          String url = remotePrefix + mediaMidi;
          String mime = "audio/midi";
          Thread t = new AudioPlayer(false, url, mime);
          t.start ();

        } else if (menu.getSelectedIndex() == 3) {
          display.setCurrent (wait);
          String url = localPrefix + mediaWav;
          String mime = "audio/x-wav";
          Thread t = new AudioPlayer(true, url, mime);
          t.start ();

        } else if (menu.getSelectedIndex() == 4) {
          display.setCurrent (wait);
          String url = remotePrefix + mediaWav;
          String mime = "audio/x-wav";
          Thread t = new AudioPlayer(false, url, mime);
          t.start ();

        } else if (menu.getSelectedIndex() == 5) {
          display.setCurrent (wait);
          String url = localPrefix + media3gpp;
          String mime = "video/3gpp";
          Thread t = new VideoPlayer(true, url, mime);
          t.start ();

        } else if (menu.getSelectedIndex() == 6) {
          display.setCurrent (wait);
          String url = remotePrefix + media3gpp;
          String mime = "video/3gpp";
          Thread t = new VideoPlayer(false, url, mime);
          t.start ();

        }
      }
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

}

class AudioPlayer extends Thread {

  private boolean local;
  private String url;
  private String mime;

  public AudioPlayer (boolean l, String u, String m) {
    local = l;
    url = u;
    mime = m;
  }

  public void run () {
    try {
      if (local) {
        InputStream is =
            getClass().getResourceAsStream (url);
        MediaPlayer.player =
            Manager.createPlayer(is, mime);
      } else {
        MediaPlayer.player = Manager.createPlayer(url);
      }

      MediaPlayer.player.addPlayerListener(
                             new StopListener ());
      MediaPlayer.player.realize();
      MediaPlayer.player.prefetch ();

      AudioForm form = new AudioForm ();
      MediaPlayer.display.setCurrent (form);

      MediaPlayer.player.start ();
    } catch (Exception e) {
      e.printStackTrace ();
    }
  }
}

class VideoPlayer extends Thread {

  private boolean local;
  private String url;
  private String mime;

  public VideoPlayer (boolean l, String u, String m) {
    local = l;
    url = u;
    mime = m;
  }

  public void run () {
    try {
      if (local) {
        InputStream is =
            getClass().getResourceAsStream (url);
        MediaPlayer.player =
            Manager.createPlayer(is, mime);
      } else {
        MediaPlayer.player = Manager.createPlayer(url);
      }

      MediaPlayer.player.realize();
      MediaPlayer.player.prefetch ();

      VideoForm form = new VideoForm ();
      MediaPlayer.display.setCurrent (form);

      form.startPlayer (MediaPlayer.player);
    } catch (Exception e) {
      e.printStackTrace ();
    }
  }
}