package com.Series40Book;

import javax.microedition.lcdui.*;


public class PhotoPreview extends Form 
             implements CommandListener {

  private Command cancel;
  private Command next;

  public PhotoPreview () {
    super ("Photo Preview");
    cancel = new Command ("Cancel", Command.CANCEL, 1);
    next = new Command ("Next", Command.OK, 1);
    addCommand (cancel);
    addCommand (next);
    setCommandListener (this);

    append (new ImageItem(
        "Image size is " + BlogClient.photoData.length,
        BlogClient.photoPreview,
        ImageItem.LAYOUT_CENTER, "image"));
  }

  public void commandAction (Command c, Displayable d) {
    if (c == cancel) {
      BlogClient.initSession();
      BlogClient.showCamera ();

    } else if (c == next) {
      BlogClient.showAudioRecorder();
    }
  }

}
