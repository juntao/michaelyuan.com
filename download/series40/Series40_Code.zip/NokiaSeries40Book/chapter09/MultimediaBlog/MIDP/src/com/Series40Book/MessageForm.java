package com.Series40Book;

import javax.microedition.lcdui.*;


public class MessageForm extends TextBox
                implements CommandListener {

  private Command submit;
  private Command cancel;

  public MessageForm () {
    super ("Message", "", 250, TextField.ANY);

    submit = new Command ("Submit", Command.OK, 1);
    cancel = new Command ("Cancel", Command.CANCEL, 1);
    addCommand (submit);
    addCommand (cancel);
    setCommandListener (this);
  }

  public void commandAction (Command c, Displayable d) {
    if (c == submit) {
      BlogClient.message = getString();
      BlogClient.startSubmit ();

    } else if (c == cancel) {
      BlogClient.initSession();
      BlogClient.showCamera();
    }
  }

}
