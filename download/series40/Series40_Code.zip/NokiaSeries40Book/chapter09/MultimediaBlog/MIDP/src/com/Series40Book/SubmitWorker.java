package com.Series40Book;

public class SubmitWorker extends Thread {

  public SubmitWorker () {
  }

  public void run () {
    BlogClient.submit ();
  }
}