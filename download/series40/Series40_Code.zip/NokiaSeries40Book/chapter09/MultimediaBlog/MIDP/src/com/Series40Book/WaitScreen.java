package com.Series40Book;

import javax.microedition.lcdui.*;

public class WaitScreen extends Canvas
                    implements CommandListener {

  private Image img;
  private Command done;

  public WaitScreen () {

    try {
      img = Image.createImage("/" + "wait.png");
    } catch (Exception e) {
      e.printStackTrace ();
      img = null;
    }
    done = new Command ("Done", Command.OK, 1);
    addCommand (done);
    setCommandListener (this);
  }

  public void commandAction (Command c, Displayable d) {
    if (c == done) {
      BlogClient.initSession ();
      BlogClient.showCamera ();
    }
  }

  public void paint (Graphics g) {

    int width = getWidth ();
    int height = getHeight ();

    g.setColor(0xffffff);
    g.fillRect(0,  0, width, height);
    g.setColor(0x000000);

    g.drawImage (img, width / 2, height / 2,
            Graphics.HCENTER | Graphics.VCENTER);
    return;
  }
}
