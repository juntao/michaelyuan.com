package com.Series40Book;

import javax.microedition.lcdui.*;


public class Report extends Form
         implements CommandListener {

  private Command exit;
  private Command start;

  public Report (String status) {
    super ("Report");

    exit = new Command ("Exit", Command.EXIT, 1);
    start = new Command ("New entry", Command.OK, 1);
    addCommand (exit);
    addCommand (start);
    setCommandListener (this);

    append (status);
    append(new StringItem("Message", BlogClient.message));
    if (BlogClient.photoData != null) {
      // Image img =
      //    Image.createImage (BlogClient.photoData, 0,
      //         BlogClient.photoData.length);
      // append (new ImageItem(
      //     "Image size is " + BlogClient.photoData.length,
      //     img, ImageItem.LAYOUT_CENTER, "image"));
      append ("Photo length is " +
              BlogClient.photoData.length);
    }

    if (BlogClient.audioData != null) {
      append ("Audio clip length is " +
              BlogClient.audioData.length);
    }
  }

  public void commandAction (Command c, Displayable d) {
    if (c == exit) {
      BlogClient.exit ();
    } if (c == start) {
      BlogClient.initSession ();
      BlogClient.showCamera ();
    }
  }
}
