package com.Series40Book;

import javax.microedition.media.*;


public class StopListener implements PlayerListener {

  public void playerUpdate (Player player,
                 String event, Object eventData) {
    try {
      if (event.equals (STOPPED) ||
          event.equals (STOPPED_AT_TIME) ||
          event.equals (ERROR) ||
          event.equals (END_OF_MEDIA)) {
        // Playback is finished
        player.deallocate ();
        player.close ();
        player = null;

      } else if (event.equals(DEVICE_UNAVAILABLE)) {
        // Incoming phone call
        player.stop();

      } else if (event.equals(DEVICE_AVAILABLE)) {
        // The phone call is finished.
        // Start from where we left off.
        player.start();

      }
      System.out.println(event);

    } catch (Exception e) {
      e.printStackTrace ();
    }
  }

}
