package com.Series40Book.PhotoServer;

import javax.servlet.http.*;
import javax.servlet.*;
import java.io.*;

public class PhotoServlet extends HttpServlet {

  private static int GET_PHOTO = 1;
  private static int GET_NEXT = 2;

  private String [] titles =
      {"Birds", "Shamu", "VLA Telescope",
       "Tunnel View", "Yosemite Fall"};
  
  private String [] descriptions = 
      {"Birds at Bosque, New Mexico",
       "Shamu at SeaWorld, Texas",
       "The VLA radio telescopes, New Mexico",
       "Tunnel View, Yosemite Valley, CA",
       "Yosemite Falls, CA"};

  private String [] filenames =
      {"/pBirds.png", "/pShamu.png", "/pVLA.png",
       "/pTunnelView.png", "/pYoseFall.png"};
  
//  private String fileroot =
//      "/Users/juntao/Java/tomcat/jakarta-tomcat-4.1.24/webapps/PhotoServer/res/";

  public void init() throws ServletException {
    // Do nothing
  }

  public void doPost(HttpServletRequest request,
                     HttpServletResponse response)
      throws ServletException, IOException {

    response.setContentType("application/binary");
    try {
      InputStream in = request.getInputStream();
      OutputStream out = response.getOutputStream();
      DataInputStream din = new DataInputStream(in);
      DataOutputStream dout = new DataOutputStream(out);

      int opcode = din.readInt();
      if (opcode == GET_PHOTO) {
        getPhoto (din, dout);
      } else if (opcode == GET_NEXT) {
        getNext (din, dout, request);
      } else {
        throw new Exception("wrong op code");
      }
      din.close();
      dout.close();
      in.close();
      out.close();

    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  private void getPhoto(DataInputStream din,
            DataOutputStream dout) throws Exception {

    byte [] buf = readFromFile (filenames[0]);

    dout.writeUTF(titles[0]);
    dout.writeUTF(descriptions[0]);
    dout.writeInt(buf.length);
    dout.write(buf, 0, buf.length);
  }

  private void getNext(DataInputStream din,
       DataOutputStream dout,
       HttpServletRequest request) throws Exception {

    int i; // The current index

    HttpSession sess = request.getSession (true);
    Integer index =
        (Integer) sess.getAttribute ("Index");

    if (index == null) {
      i = 0;
    } else {
      i = index.intValue();
      if (i >= titles.length) {
        i = 0;
      }
    }
    sess.setAttribute("Index", new Integer(i+1));

    byte [] buf = readFromFile (filenames[i]);

    dout.writeUTF(titles[i]);
    dout.writeUTF(descriptions[i]);
    dout.writeInt(buf.length);
    dout.write(buf, 0, buf.length);
  }


  private byte [] readFromFile (String name)
                                 throws Exception {
//    FileInputStream fin =
//        new FileInputStream(fileroot + name);
//    ByteArrayOutputStream baos =
//                       new ByteArrayOutputStream ();
//    byte [] buf = new byte [256];
//    int i = 0;
//    while ( (i = fin.read(buf)) != -1 ) {
//      baos.write(buf, 0, i);
//    }
//    baos.flush();
//    byte [] result = baos.toByteArray();
//    baos.close();
//    fin.close();
//    return result;

    InputStream in =
       this.getClass().getResourceAsStream(name);
    ByteArrayOutputStream baos =
                     new ByteArrayOutputStream ();
    byte [] buf = new byte [256];
    int i = 0;
    while ( (i = in.read(buf)) != -1 ) {
      baos.write(buf, 0, i);
    }
    baos.flush();
    byte [] result = baos.toByteArray();
    baos.close();
    in.close();
    return result;
  }

}
