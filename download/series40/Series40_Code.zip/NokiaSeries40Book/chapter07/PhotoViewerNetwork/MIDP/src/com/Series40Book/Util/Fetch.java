package com.Series40Book.Util;

import java.io.*;
import javax.microedition.io.*;
import javax.microedition.lcdui.*;
import com.Series40Book.HttpClient.*;

public class Fetch {

  private String url;
  private int GET_PHOTO = 1;
  private int GET_NEXT = 2;

  protected String title;
  protected String description;
  protected Image img;
  protected boolean isSuccessful;

  public Fetch (String url) {
    this.url = url;
    title = "error";
    description = "error";
    img = null;
    isSuccessful = false;
  }

  // This is a template method
  protected void updateWaitStatus () { }


  protected void getPhoto () {

    HttpConnection conn = null;
    DataInputStream din = null;
    DataOutputStream dout = null;

    try {
      conn = (HttpConnection) Connector.open(url);
      conn.setRequestMethod(HttpConnection.POST);

      dout = conn.openDataOutputStream ();
      dout.writeInt (GET_PHOTO);
      dout.flush ();
      dout.close ();
      updateWaitStatus ();

      din = conn.openDataInputStream();
      title = din.readUTF ();
      updateWaitStatus ();
      description = din.readUTF ();
      updateWaitStatus ();
      int size = din.readInt ();
      updateWaitStatus ();
      byte [] buf = new byte [size];
      din.readFully(buf);
      updateWaitStatus ();
      img = Image.createImage (buf, 0, buf.length);
      updateWaitStatus ();
      
      isSuccessful = true;

    } catch (Exception exp) {
      exp.printStackTrace ();
      isSuccessful = false;
    } finally {
      try {
        if (dout != null) dout.close ();
        if (din != null) din.close();
        if (conn != null) conn.close();
      } catch (Exception exp) {}
    }
  }

  protected void getNext () {

    HttpConnection conn = null;
    DataInputStream din = null;
    DataOutputStream dout = null;

    try {

      conn =
          (HttpConnection) SessionConnector.open(url);
      conn.setRequestMethod(HttpConnection.POST);

      dout = conn.openDataOutputStream ();
      dout.writeInt (GET_NEXT);
      dout.flush ();
      dout.close ();

      updateWaitStatus ();

      din = conn.openDataInputStream();
      title = din.readUTF ();

      updateWaitStatus ();

      description = din.readUTF ();

      updateWaitStatus ();

      int size = din.readInt ();

      updateWaitStatus ();

      byte [] buf = new byte [size];
      din.readFully(buf);

      updateWaitStatus ();

      img = Image.createImage (buf, 0, buf.length);

      updateWaitStatus ();

      isSuccessful = true;

    } catch (Exception exp) {
      exp.printStackTrace ();
      isSuccessful = false;

    } finally {
      try {
        if (dout != null) dout.close ();
        if (din != null) din.close();
        if (conn != null) conn.close();
      } catch (Exception exp) {}
    }
  }


  protected void getNext (HttpClient client) {

    byte [] networkBuffer;
    DataInputStream din = null;
    DataOutputStream dout = null;
    ByteArrayInputStream bin = null;
    ByteArrayOutputStream bout = null;

    try {
      bout = new ByteArrayOutputStream ();
      dout = new DataOutputStream (bout);
      dout.writeInt(GET_NEXT);
      dout.flush();
      dout.close();
      networkBuffer = bout.toByteArray();
      updateWaitStatus ();

      networkBuffer = client.query(networkBuffer);
      updateWaitStatus ();

      bin = new ByteArrayInputStream (networkBuffer);
      din = new DataInputStream (bin);
      title = din.readUTF ();
      updateWaitStatus ();
      description = din.readUTF ();
      updateWaitStatus ();
      int size = din.readInt ();
      updateWaitStatus ();
      byte [] buf = new byte [size];
      din.readFully(buf);
      updateWaitStatus ();
      img = Image.createImage (buf, 0, buf.length);
      updateWaitStatus ();

      isSuccessful = true;

    } catch (Exception exp) {
      exp.printStackTrace ();
      isSuccessful = false;

    } finally {
      try {
        if (dout != null) dout.close ();
        if (din != null) din.close();
        if (bout != null) bout.close();
        if (bin != null) bin.close ();
      } catch (Exception exp) {}
    }
  }

}
