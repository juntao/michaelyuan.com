#!/bin/sh
# convenience script file to build with

ANT_HOME=../../tools/apache-ant-1.6.2
PATH=$ANT_HOME/bin:$PATH
ant $*
