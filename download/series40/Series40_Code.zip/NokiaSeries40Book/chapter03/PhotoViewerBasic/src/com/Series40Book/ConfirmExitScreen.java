package com.Series40Book;

import javax.microedition.lcdui.*;

/**
 * Confirm exit
 */
public class ConfirmExitScreen extends Form 
                    implements CommandListener {

  private PhotoViewer viewer;
  private Command yes;
  private Command no;

  public ConfirmExitScreen (PhotoViewer v) {
    super ("Confirm");
    viewer = v;

    yes = new Command ("Yes", Command.OK, 1);
    no = new Command ("No", Command.BACK, 1);

    append ("Really exit?");
    addCommand (yes);
    addCommand (no);
    setCommandListener (this);
  }


  public void commandAction (Command c, Displayable d) {
    if ( c == yes ) {
      viewer.exitConfirmed = true;
      viewer.safeShutdown ();
    } else {
      viewer.exitConfirmed = false;
      viewer.resume();
    }
  }

}