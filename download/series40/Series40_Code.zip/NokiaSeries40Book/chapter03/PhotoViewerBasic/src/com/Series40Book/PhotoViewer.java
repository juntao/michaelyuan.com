package com.Series40Book;

import javax.microedition.lcdui.*;
import javax.microedition.midlet.*;
import java.util.*;

public class PhotoViewer extends MIDlet
              implements CommandListener {

  private Display display;
  private Command next;
  private Command exit;
  private Command start;
  private Command stop;
  private Form imageForm;

  private String [] imageNames;
  private String [] imageFileNames;
  private int imageIdx;
  private Timer autoShowTimer;

  boolean exitConfirmed;

  public PhotoViewer () {

    int numOfImages =
  Integer.parseInt(getAppProperty("NumberOfImages"));
    imageNames = new String [numOfImages];
    imageFileNames = new String [numOfImages];
    for (int i = 0; i < numOfImages; i++) {
      int tmpi = i + 1;
      String tmp = getAppProperty("Image-" + tmpi);
      int cIdx = tmp.indexOf(",");
      imageFileNames[i] = tmp.substring(0, cIdx).trim();
      imageNames[i] = tmp.substring(cIdx+1).trim();
    }
    imageIdx = 0;

    display = Display.getDisplay (this);
    imageForm = new Form ("Photo show");

    start =
        new Command ("Start", Command.SCREEN, 1);
    imageForm.addCommand (start);

    stop = new Command ("Stop", Command.STOP, 1);
    imageForm.addCommand (stop);

    next = new Command ("Next", Command.OK, 1);
    imageForm.addCommand (next);

    exit = new Command ("Exit", Command.EXIT, 1);
    imageForm.addCommand (exit);

    imageForm.setCommandListener (this);
  }

  private void showImage (int index) {


    imageForm.deleteAll();

    /* Use the following alternative on MIDP 1 devices
    try {
      imageForm.delete(0);
    } catch (Exception e) {
      // The first imageForm always throws this exception
      e.printStackTrace ();
    }
    */

    Image img;
    try {
      img = Image.createImage("/" +
                     imageFileNames[index]);
    } catch (Exception e) {
      e.printStackTrace ();
      img = null;
    }
    ImageItem imgItem =
       new ImageItem(imageNames[index], img,
                     ImageItem.LAYOUT_CENTER, "image");
    imageForm.append(imgItem);

    display.setCurrent(imageForm);
  }

  public void showNext () {
    imageIdx++;
    if (imageIdx > imageNames.length - 1) {
      imageIdx = 0;
    }
    showImage (imageIdx);
  }


  private void stopShow () {
    if (autoShowTimer != null) {
      autoShowTimer.cancel ();
    }
  }

  private void startShow () {
    stopShow ();
    autoShowTimer = new Timer ();
    AutoShowTask r = new AutoShowTask (this);
    autoShowTimer.schedule(r, 0, 5000);
  }

  protected void startApp () {
    showImage(imageIdx);
    exitConfirmed = false;
  }

  protected void pauseApp () {
    // Not supported in Nokia devices
  }

  protected void destroyApp (boolean unconditional)
                      throws MIDletStateChangeException {
    // Stop any auto show
    stopShow ();

    // Only check confirmation if this is a conditional
    // shutdown (i.e., not shutdown by pressing the
    // End key.
    if (!unconditional) {
      if (!exitConfirmed) {
        throw new MIDletStateChangeException ();
      }
    }
  }

  public void safeShutdown () {
    try {
      destroyApp (false);
      notifyDestroyed ();
    } catch (MIDletStateChangeException me) {
      display.setCurrent(new ConfirmExitScreen(this));
    }
  }

  public void resume () {
    display.setCurrent(imageForm);
  }

  public void commandAction (Command c, Displayable d) {
    if (c == exit) {
      safeShutdown ();

    } else if (c == start) {
      startShow ();

    } else if (c == stop) {
      stopShow ();

    } else if (c == next) {
      showNext ();
    }
  }

}

class AutoShowTask extends TimerTask {

  private PhotoViewer viewer;

  public AutoShowTask (PhotoViewer s) {
    viewer = s;
  }

  public void run () {
    System.out.println("In the timer task");
    viewer.showNext ();
  }
}