package com.Series40Book.BasicUI;

import javax.microedition.lcdui.*;


public class TextBoxDemo extends TextBox
              implements CommandListener {

  private Command report;
  private Command clear;
  private Command notice;
  private CommandListener comm;

  public TextBoxDemo (CommandListener c) {
    super ("Demo TextBox", "", 256, TextField.ANY);
    comm = c;

    report = new Command ("Report", Command.SCREEN, 2);
    clear = new Command ("Clear", Command.SCREEN, 2);
    notice = new Command ("Notice", Command.SCREEN, 2);

    addCommand (report);
    addCommand (clear);
    addCommand (notice);
    setCommandListener (this);
  }

  public void commandAction (Command c, Displayable d) {
    if (c == report) {
      Form result = new InfoForm ("Result", this);
      result.append ("Text in the box is: " +
              this.getString());
      result.append("\n");
      result.append ("Text size: " + this.size());
      result.append("\n");
      result.append("Cursor position: " +
              this.getCaretPosition());

      DriverMidlet.display.setCurrent (result);

    } else if (c == clear) {
      this.delete(0, this.size());

    } else if (c == notice) {
      this.insert("Copyright, Michael Yuan.",
                  this.size());
    }
    comm.commandAction(c, d);
  }

}
