package com.Series40Book.BasicUI;

import javax.microedition.lcdui.*;


public class ImageButtonDemo extends Form
              implements CommandListener {

  private CommandListener comm;
  private TextField textField;
  private ImageButtonItem imageButton;

  public ImageButtonDemo (CommandListener c) {
    super ("Photo Button");
    comm = c;

    textField = new TextField("Your message",
            "", 20, TextField.ANY);
    imageButton = new ImageButtonItem();
    imageButton.setLayout(Item.LAYOUT_CENTER);
    imageButton.textField = textField;

    append (textField);
    append (imageButton);

    setCommandListener (this);
  }

  public void commandAction (Command c, Displayable d) {
    comm.commandAction(c, d);
  }

}
