package com.Series40Book.BasicUI;

import javax.microedition.lcdui.*;


public class TextFieldDemo extends Form
              implements CommandListener {

  private Command report;
  private CommandListener comm;
  private TextField name;
  private TextField phonenumber;
  private TextField email;

  public TextFieldDemo (CommandListener c) {
    super ("Text field");
    comm = c;

    report = new Command ("Report", Command.SCREEN, 2);

    name = new TextField ("Your name", "", 20,
                        TextField.INITIAL_CAPS_WORD);
    append (name);

    phonenumber = new TextField ("Phone numbr", "", 20,
                        TextField.PHONENUMBER);
    append (phonenumber);

    email = new TextField ("Email", "", 20,
            TextField.EMAILADDR | TextField.SENSITIVE);
    append (email);

    addCommand (report);
    setCommandListener (this);
  }

  public void commandAction (Command c, Displayable d) {
    if (c == report) {

      Form form = new InfoForm ("User profile", this);
      form.append ("Name: " + name.getString() + "\n");
      form.append ("Phone: " +
                   phonenumber.getString() + "\n");
      form.append ("Email: " +
                   email.getString() + "\n");

      name.delete(0, name.size());
      phonenumber.delete(0, phonenumber.size());
      email.delete(0, email.size());

      DriverMidlet.display.setCurrent(form);
    }
    comm.commandAction(c, d);
  }
}