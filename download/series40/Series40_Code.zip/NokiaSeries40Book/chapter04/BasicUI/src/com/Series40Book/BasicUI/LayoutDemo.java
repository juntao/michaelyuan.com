package com.Series40Book.BasicUI;

import javax.microedition.lcdui.*;


public class LayoutDemo extends Form
             implements CommandListener {

  private CommandListener comm;
  private Image img;

  public LayoutDemo (CommandListener c) {
    super ("Layout Demo");
    comm = c;
    try {
      img = Image.createImage("/music.png");
    } catch (Exception e) {
      e.printStackTrace ();
      img = null;
    }

    int layout = Item.LAYOUT_2 | Item.LAYOUT_TOP |
        Item.LAYOUT_LEFT;
    ImageItem ii = new ImageItem ("", img, layout, "");
    append (ii);
    StringItem si = new StringItem ("", "Music");
    si.setLayout (layout | Item.LAYOUT_NEWLINE_AFTER);
    append (si);

    layout = Item.LAYOUT_2 | Item.LAYOUT_BOTTOM |
        Item.LAYOUT_LEFT;
    ii = new ImageItem ("", img, layout, "");
    append (ii);
    si = new StringItem ("", "Music\n");
    si.setLayout (layout);
    append (si);

    layout = Item.LAYOUT_2 | Item.LAYOUT_VCENTER |
        Item.LAYOUT_LEFT;
    ii = new ImageItem ("", img, layout, "");
    append (ii);
    si = new StringItem ("", "Music\n");
    si.setLayout (layout);
    append (si);

    layout = Item.LAYOUT_2 | Item.LAYOUT_CENTER;
    ii = new ImageItem ("", img, layout, "");
    append (ii);

    layout = Item.LAYOUT_2 | Item.LAYOUT_RIGHT;
    ii = new ImageItem ("", img, layout, "");
    append (ii);



    // setFullScreenMode (true);
    setCommandListener (this);
  }


  public void commandAction (Command c, Displayable d) {
    comm.commandAction(c, d);
  }

}
