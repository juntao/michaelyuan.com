package com.Series40Book.BasicUI;

import javax.microedition.lcdui.*;


public class PopupDemo extends Form
               implements CommandListener {

  private Command report;
  private ChoiceGroup choices;
  private CommandListener comm;

  public PopupDemo (CommandListener c) {
    super ("Choice demo");
    comm = c;

    choices = new ChoiceGroup ("How much do you pay " +
            "for wireless services each month?",
            Choice.POPUP);
    choices.append("0 to 10", null);
    choices.append("11 to 20", null);
    choices.append("21 to 30", null);
    choices.append("above 30", null);
    append (choices);

    report = new Command ("Report", Command.SCREEN, 2);

    addCommand (report);
    setCommandListener (this);
  }

  public void commandAction (Command c, Displayable d) {
    if (c == report) {
      int index = choices.getSelectedIndex();
      Form form = new InfoForm ("Result", this);
      form.append("You are paying ");
      form.append(choices.getString(index));
      form.append(" per month");
      DriverMidlet.display.setCurrent(form);
    }
    comm.commandAction(c, d);
  }
}
