package com.Series40Book.BasicUI;

import javax.microedition.lcdui.*;


public class WrapTextDemo extends ScrollCanvas {

  private CommandListener comm;

  private String sample =
          "The quick brown fox jumps over " +
          "the lazy dog";

  private Font font01 =
      Font.getFont(Font.FACE_PROPORTIONAL,
            Font.STYLE_PLAIN, Font.SIZE_LARGE);
  private Font font02 =
      Font.getFont(Font.FACE_PROPORTIONAL,
            Font.STYLE_BOLD, Font.SIZE_LARGE);
  private Font font03 =
      Font.getFont(Font.FACE_PROPORTIONAL,
            Font.STYLE_ITALIC, Font.SIZE_LARGE);
  private Font font04 =
      Font.getFont(Font.FACE_PROPORTIONAL,
            Font.STYLE_ITALIC | Font.STYLE_UNDERLINED,
            Font.SIZE_LARGE);

  public WrapTextDemo (CommandListener c) {
    comm = c;
    setCommandListener (this);
  }

  protected void paint (Graphics g) {

    g.setColor(0xffffff);
    g.fillRect(0,  0, w, h);
    g.setColor(0x000000);

    int x = startX;
    int y = startY;

    y = TextWrapUtil.drawMultilineString(g, font01,
            sample, x, y + font01.getHeight(),
            Graphics.BASELINE | Graphics.LEFT, w);

    y = TextWrapUtil.drawMultilineString(g, font02,
            sample, x, y + font02.getHeight(),
            Graphics.BASELINE | Graphics.LEFT, w);


    y = TextWrapUtil.drawMultilineString(g, font03,
            sample, x, y + font03.getHeight(),
            Graphics.BASELINE | Graphics.LEFT, w);


    y = TextWrapUtil.drawMultilineString(g, font04,
            sample, x, y + font04.getHeight(),
            Graphics.BASELINE | Graphics.LEFT, w);
  }

  protected void keyReleased (int keyCode) {
    // Screen specific logic goes here
    super.keyReleased (keyCode);
  }

  public void commandAction(Command c, Displayable d) {
    comm.commandAction(c, d);
    super.commandAction(c, d);
  }

}
