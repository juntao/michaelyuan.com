package com.Series40Book.BasicUI;

import javax.microedition.lcdui.*;


// This is a utility form that provides some info and a
// "back" button
public class InfoForm extends Form
         implements CommandListener {

  private Displayable prev;
  private Command back;

  public InfoForm (String title, Displayable prev) {
    super (title);
    this.prev = prev;

    back = new Command ("Back", Command.BACK, 1);
    addCommand (back);
    setCommandListener (this);
  }

  public void commandAction (Command c, Displayable d) {
    if (c == back) {
      DriverMidlet.display.setCurrent (prev);
    }
  }
}
