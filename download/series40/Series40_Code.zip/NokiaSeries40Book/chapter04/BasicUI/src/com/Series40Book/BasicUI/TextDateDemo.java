package com.Series40Book.BasicUI;

import javax.microedition.lcdui.*;
import java.util.*;

public class TextDateDemo extends Form
              implements CommandListener {

  private Command report;
  private CommandListener comm;
  private TextField name;
  private DateField logtime;

  public TextDateDemo (CommandListener c) {
    super ("Text field");
    comm = c;

    report = new Command ("Report", Command.SCREEN, 2);

    name = new TextField ("Your name", "", 20,
                        TextField.INITIAL_CAPS_WORD);
    append (name);

    logtime = new DateField ("Log time",
                             DateField.DATE_TIME);
    // We can initialize the DateField to the
    // current time using the statement below.
    // In the demo, we choose to show the DateField
    // in its un-initialized state
    //
    // logtime.setDate(new Date());
    append (logtime);

    addCommand (report);
    setCommandListener (this);
  }

  public void commandAction (Command c, Displayable d) {
    if (c == report) {

      Form form = new InfoForm ("User profile", this);
      form.append ("Name: " + name.getString() + "\n");

      Calendar cal = Calendar.getInstance();
      cal.setTime (logtime.getDate());
      form.append ("Log time: " +
                   cal.toString() + "\n");

      name.delete(0, name.size());

      DriverMidlet.display.setCurrent(form);
    }
    comm.commandAction(c, d);
  }
}