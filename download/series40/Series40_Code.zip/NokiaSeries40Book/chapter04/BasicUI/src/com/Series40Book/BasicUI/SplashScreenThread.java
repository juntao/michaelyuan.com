package com.Series40Book.BasicUI;

import javax.microedition.lcdui.*;


public class SplashScreenThread extends Thread {

  private DriverMidlet driver;

  public SplashScreenThread (DriverMidlet d) {
    driver = d;
  }

  public synchronized void run () {
    // Instaniate a splash screen and display it
    SplashScreen s = new SplashScreen (driver);
    DriverMidlet.display.setCurrent(s);

    // Do the startup work
    // and/or animate the splash screen
    // Here, we just have a simple count down
    for (int i = 10; i > 0; i--) {
      try {
        s.show (i);
        this.wait (1000);
      } catch (InterruptedException ie) {
        // do nothing
      }
    }

    // Display the main app screen
    driver.next ();
  }
}

class SplashScreen extends Canvas
         implements CommandListener {

  protected int width, height;
  protected int count = 10;
  Command exit;
  private DriverMidlet driver;

  public SplashScreen (DriverMidlet d) {
    width = getWidth ();
    height = getHeight ();
    driver = d;
    exit = new Command ("Exit", Command.EXIT, 0);
    addCommand (exit);
    setCommandListener (this);
  }

  public void commandAction(Command c, Displayable s) {
    if (c == exit) {
      driver.exit ();
    }
  }

  public void show (int i) {
    count = i;
    repaint ();
  }

  protected void paint (Graphics g) {
    g.setColor(0xffffff);
    g.fillRect(0,  0, width, height);
    g.setColor(0x000000);

    g.drawString ("Welcome", width / 2, height / 4,
            Graphics.BASELINE | Graphics.HCENTER);
    g.drawString (Integer.toString(count),
            width / 2, height * 3/4,
            Graphics.BASELINE | Graphics.HCENTER);
  }

}
