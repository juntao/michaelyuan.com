package com.Series40Book.BasicUI;

import javax.microedition.lcdui.*;
import javax.microedition.midlet.*;

public class DriverMidlet extends MIDlet
                 implements CommandListener {

  static Display display;
  private static Displayable demo;
  private static int index = -1;

  Command exit = new Command ("Exit", Command.EXIT, 1);
  Command next = new Command ("Next", Command.OK, 1);

  public DriverMidlet () {
    display = Display.getDisplay(this);
  }

  public void commandAction (Command c, Displayable d) {
    if (c == exit) {
      exit ();
    } else if (c == next) {
      next ();
    }
  }

  protected void startApp () {
    // Use the following statement if you do not want
    // the splash screen.
    //
    // next ();

    // The following statement is for the splash screen
    Thread t = new SplashScreenThread (this);
    t.start();
  }

  protected void pauseApp () {
    // Do nothing
  }

  protected void destroyApp (boolean unconditional) {
    notifyDestroyed ();
  }

  public void next () {
    index++;
    if (index > 16) {
      index = 0;
    }

    switch (index) {
      case 0: demo  = new DeviceInfoDemo (this); break;
      case 1: demo  = new AlertDemo (this); break;
      case 2: demo  = new ListDemo (this); break;
      case 3: demo  = new MenuDemo (this); break;
      case 4: demo  = new TextBoxDemo (this); break;
      case 5: demo  = new TextDateDemo (this); break;
      case 6: demo  = new ChoiceGroupDemo (this); break;
      case 7: demo  = new PopupDemo (this); break;
      case 8: demo  = new GaugeDemo (this); break;
      case 9: demo  = new StringImageDemo (this); break;
      case 10: demo  = new LayoutDemo (this); break;
      case 11: demo  = new ItemCommandDemo (this); break;
      case 12: demo  = new CanvasDemo (this); break;
      case 13: demo = new AnimationDemo (this); break;
      case 14: demo = new ScrollCanvasDemo (this); break;
      case 15: demo = new WrapTextDemo (this); break;
      case 16: demo = new ImageButtonDemo (this); break;
    }

    /*if (index == 0) {
      demo  = new DeviceInfoDemo (this);
    } else if (index == 1) {
      demo  = new AlertDemo (this);
    } else if (index == 2) {
      demo  = new ListDemo (this);
    } else if (index == 3) {
      demo  = new MenuDemo (this);
    } else if (index == 4) {
      demo  = new TextBoxDemo (this);
    } else if (index == 5) {
      demo  = new TextDateDemo (this);
    } else if (index == 6) {
      demo  = new ChoiceGroupDemo (this);
    } else if (index == 7) {
      demo  = new PopupDemo (this);
    } else if (index == 8) {
      demo  = new GaugeDemo (this);
    } else if (index == 9) {
      demo  = new StringImageDemo (this);
    } else if (index == 10) {
      demo  = new LayoutDemo (this);
    } else if (index == 11) {
      demo  = new ItemCommandDemo (this);
    } else if (index == 12) {
      demo  = new CanvasDemo (this);
    } else if (index == 13) {
      demo = new AnimationDemo (this);
    } else if (index == 14) {
      demo = new ScrollCanvasDemo (this);
    } else if (index == 15) {
      demo = new WrapTextDemo (this);
    } else if (index == 16) {
      demo = new ImageButtonDemo (this);
    }*/

    demo.addCommand (exit);
    demo.addCommand (next);

    display.setCurrent(demo);
  }

  public void exit () {
    destroyApp (true);
  }

}
