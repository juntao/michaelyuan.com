package com.Series40Book.BasicUI;

import javax.microedition.lcdui.*;


public class MenuDemo extends List
        implements CommandListener {

  private Command go;
  private CommandListener comm;
  private Image icon;

  public MenuDemo (CommandListener c) {
    super ("Select one", Choice.IMPLICIT);
    comm = c;

    try {
      icon = Image.createImage("/" + "fly.png");
    } catch (Exception e) {
      icon = null;
    }

    append ("New York", icon);
    append ("Paris", icon);
    append ("Dallas", icon);
    append ("Beijing", icon);

    go = new Command ("Go", Command.SCREEN, 2);

    setSelectCommand(go);
    setCommandListener (this);
  }

  public void commandAction (Command c, Displayable d) {
    if (c == go) {
      int i = getSelectedIndex ();

      Form form = new InfoForm ("Result", this);
      form.append ("Your destination is \n");
      form.append (getString(i) + "\n");

      DriverMidlet.display.setCurrent(form);
    }
    comm.commandAction(c, d);
  }

}

