package com.Series40Book.BasicUI;

import javax.microedition.lcdui.*;


public class ScrollCanvasDemo extends ScrollCanvas {

  private CommandListener comm;

  private String sample =
          "The quick brown fox jumps over " +
          "the lazy dog";
  
  private Font font01 = 
      Font.getFont(Font.FACE_PROPORTIONAL,
            Font.STYLE_PLAIN, Font.SIZE_LARGE);
  private Font font02 = 
      Font.getFont(Font.FACE_PROPORTIONAL,
            Font.STYLE_BOLD, Font.SIZE_LARGE);
  private Font font03 =
      Font.getFont(Font.FACE_PROPORTIONAL,
            Font.STYLE_ITALIC, Font.SIZE_LARGE);
  private Font font04 =
      Font.getFont(Font.FACE_PROPORTIONAL,
            Font.STYLE_UNDERLINED, Font.SIZE_LARGE);
  private Font font05 =
      Font.getFont(Font.FACE_PROPORTIONAL,
            Font.STYLE_ITALIC | Font.STYLE_UNDERLINED,
            Font.SIZE_LARGE);
  private Font font06 =
      Font.getFont(Font.FACE_MONOSPACE,
            Font.STYLE_PLAIN, Font.SIZE_LARGE);
  private Font font07 =
      Font.getFont(Font.FACE_MONOSPACE,
            Font.STYLE_BOLD, Font.SIZE_LARGE);
  private Font font08 =
      Font.getFont(Font.FACE_MONOSPACE,
            Font.STYLE_ITALIC, Font.SIZE_LARGE);
  private Font font09 =
      Font.getFont(Font.FACE_MONOSPACE,
            Font.STYLE_ITALIC | Font.STYLE_UNDERLINED,
            Font.SIZE_LARGE);


  public ScrollCanvasDemo (CommandListener c) {
    comm = c;
    setCommandListener (this);
  }

  protected void paint (Graphics g) {
    g.setColor(0xffffff);
    g.fillRect(0,  0, w, h);
    g.setColor(0x000000);
    
    int x = startX;
    int y = startY;

    g.setFont (font01);
    y += font01.getHeight() + 5;
    g.drawString (sample, x, y,
            Graphics.BASELINE | Graphics.LEFT);

    g.setFont (font02);
    y += font02.getHeight() + 5;
    g.drawString (sample, x, y,
            Graphics.BASELINE | Graphics.LEFT);

    g.setFont (font03);
    y += font03.getHeight() + 5;
    g.drawString (sample, x, y,
            Graphics.BASELINE | Graphics.LEFT);

    g.setFont (font04);
    y += font04.getHeight() + 5;
    g.drawString (sample, x, y,
            Graphics.BASELINE | Graphics.LEFT);

    g.setFont (font05);
    y += font05.getHeight() + 5;
    g.drawString (sample, x, y,
            Graphics.BASELINE | Graphics.LEFT);

    g.setFont (font06);
    y += font06.getHeight() + 5;
    g.drawString (sample, x, y,
            Graphics.BASELINE | Graphics.LEFT);

    g.setFont (font07);
    y += font07.getHeight() + 5;
    g.drawString (sample, x, y,
            Graphics.BASELINE | Graphics.LEFT);

    g.setFont (font08);
    y += font08.getHeight() + 5;
    g.drawString (sample, x, y,
            Graphics.BASELINE | Graphics.LEFT);

    g.setFont (font09);
    y += font09.getHeight() + 5;
    g.drawString (sample, x, y,
            Graphics.BASELINE | Graphics.LEFT);
  }
  
  protected void keyReleased (int keyCode) {
    // Screen specific logic goes here
    super.keyReleased (keyCode); 
  }

  public void commandAction(Command c, Displayable d) {    
    comm.commandAction(c, d);
    super.commandAction(c, d);
  }

}
