package com.Series40Book.BasicUI;

import javax.microedition.lcdui.*;


public class GaugeDemo extends Form
          implements CommandListener {

  private Command report;
  private Gauge interactiveGauge;
  private Gauge autoGauge;
  private CommandListener comm;

  public GaugeDemo (CommandListener c) {
    super ("Gauge");
    comm = c;

    interactiveGauge =
            new Gauge ("You satisfaction level",
                       true, 10, 5);
    autoGauge = new Gauge ("A running gauge", false,
          Gauge.INDEFINITE, Gauge.CONTINUOUS_RUNNING);

    append (interactiveGauge);
    append (autoGauge);

    report = new Command ("Report", Command.SCREEN, 2);

    addCommand (report);
    setCommandListener (this);
  }


  public void commandAction (Command c, Displayable d) {
    if (c == report) {
      Form form = new InfoForm ("Result", this);
      form.append ("Your satisfaction level is \n");
      form.append (interactiveGauge.getValue() + "\n");

      DriverMidlet.display.setCurrent(form);
    }
    comm.commandAction(c, d);
  }

}
