package com.Series40Book.BasicUI;

import javax.microedition.lcdui.*;


public class AlertDemo extends Form
              implements CommandListener {

  private Command alarm;
  private Command confirm;
  private CommandListener comm;

  public AlertDemo (CommandListener c) {
    super ("Show Alert");
    append ("Use soft button menu to display alert");

    comm = c;
    alarm = new Command ("Alarm", Command.SCREEN, 2);
    confirm = new Command ("Confirm", Command.SCREEN, 2);

    addCommand (alarm);
    addCommand (confirm);
    setCommandListener (this);
  }

  public void commandAction (Command c, Displayable d) {
    if (c == alarm) {
      Display display = DriverMidlet.display;
      Alert alert = new Alert ("Alarm Demo",
              "Attention!", null,
              AlertType.ALARM);
      alert.setTimeout(Alert.FOREVER);
      display.setCurrent (alert, this);

    } else if (c == confirm) {
      Display display = DriverMidlet.display;
      Alert alert = new Alert ("Confirmation Demo",
              "Transaction finished", null,
              AlertType.CONFIRMATION);
      alert.setTimeout(6000);
      display.setCurrent (alert, this);
    }
    comm.commandAction(c, d);
  }

}

/* Not recommanded
class CustomAlert extends AlertType {

  public CustomAlert () {
    super ();
  }

  // This method vibrates the device to alert the
  // user instead of playing the sound.
  public boolean playSound (Display display) {
    display.vibrate(3000);
    return true;
  }

}
*/
