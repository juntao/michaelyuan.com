package com.Series40Book.BasicUI;

import javax.microedition.lcdui.*;


public class StringImageDemo extends Form
                implements CommandListener {

  private CommandListener comm;

  public StringImageDemo (CommandListener c) {
    super ("String and Image items");
    comm = c;

    StringItem title = new StringItem("Telescope",
            "VLA, New Mexico, USA", Item.BUTTON);
    title.setFont(Font.getFont(Font.FACE_MONOSPACE,
            Font.STYLE_ITALIC | Font.STYLE_UNDERLINED,
            Font.SIZE_MEDIUM));
    Image img;
    try {
      img = Image.createImage("/" + "telescope.png");
    } catch (Exception e) {
      e.printStackTrace ();
      img = null;
    }
    ImageItem imgItem =
            new ImageItem("VLA telescope", img,
                    ImageItem.LAYOUT_CENTER, "VLA");

    append (title);
    append (new Spacer(10, 20));
    append (imgItem);

    setCommandListener (this);
  }

  public void commandAction (Command c, Displayable d) {
    comm.commandAction(c, d);
  }

}
