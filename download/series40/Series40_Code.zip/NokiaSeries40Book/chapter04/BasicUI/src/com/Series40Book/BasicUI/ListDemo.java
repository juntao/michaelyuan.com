package com.Series40Book.BasicUI;

import javax.microedition.lcdui.*;


public class ListDemo extends List
          implements CommandListener{

  private Command report;
  private CommandListener comm;

  public ListDemo (CommandListener c) {
    super ("Select one or more", Choice.MULTIPLE);
    comm = c;

    append ("Choice 1", null);
    append ("Choice 2", null);
    append ("Choice 3", null);
    append ("Choice 4", null);
    // Flag item 3 as selected
    setSelectedIndex (2, true);

    report = new Command ("Report", Command.SCREEN, 2);

    addCommand (report);
    setCommandListener (this);
  }


  public void commandAction (Command c, Displayable d) {
    if (c == report) {
      boolean [] selections = new boolean [size()];
      getSelectedFlags (selections);

      Form form = new InfoForm ("Result", this);
      form.append ("Selected items: \n");

      for (int i = 0 ; i < selections.length; i++) {
        if (selections[i]) {
          form.append (getString(i) + "\n");
        }
      }
      DriverMidlet.display.setCurrent(form);
    }
    comm.commandAction(c, d);
  }
}
