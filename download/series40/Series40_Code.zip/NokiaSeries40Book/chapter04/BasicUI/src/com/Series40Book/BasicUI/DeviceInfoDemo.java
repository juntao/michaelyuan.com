package com.Series40Book.BasicUI;

import javax.microedition.lcdui.*;


public class DeviceInfoDemo extends Form
               implements CommandListener {

  private Command flash;
  private Command vibrate;
  private Command device;
  private Command screen;
  private CommandListener comm;

  private Display display;

  public DeviceInfoDemo (CommandListener c) {
    super ("Device Info");
    this.display = DriverMidlet.display;
    comm = c;

    // flash = new Command ("Flash", "Flash the backlight!",
    //         Command.SCREEN, 2);
    flash = new Command ("Flash", Command.SCREEN, 2);
    vibrate = new Command ("Vibrate", Command.SCREEN, 2);
    device = new Command ("Device", Command.SCREEN, 2);
    screen = new Command ("Screen", Command.SCREEN, 2);

    this.addCommand (flash);
    this.addCommand (vibrate);
    this.addCommand (device);
    this.addCommand (screen);
    this.setCommandListener(this);

    Ticker ticker = new Ticker("Please choose from " +
            "the command butttons below");
    this.setTicker(ticker);
  }

  public void commandAction (Command c, Displayable d) {
    if (c == flash) {
      // Flash the backlight for 5000 milliseconds
      display.flashBacklight(5000);
    } else if (c == vibrate) {
      // Vibrate for 5 seconds (5000 milliseconds)
      display.vibrate(5000);
    } else if (c == device) {
      Form form = new InfoForm ("Display Info", this);
      getDisplayInfo (form);
      display.setCurrent (form);
    } else if (c == screen) {
      Form form = new InfoForm ("Displayable Info", this);
      getDisplayableInfo (form);

      Ticker ticker =
              new Ticker ("This is a rolling ticker");
      form.setTicker(ticker);
      display.setCurrent (form);
    }
    comm.commandAction(c, d);
  }

  private void getDisplayInfo (Form form) {
    // Query device characteristics
    form.append ("Does the LCD support color? " +
      (new Boolean(display.isColor())).toString());
    form.append ("\n");
    // Number of supported colors or grey scale shades
    form.append ("Number of colors: " +
            display.numColors());
    form.append("\n");
    // Number of alpha transparency levels
    form.append ("Number of alpha levels: " +
            display.numAlphaLevels());
    form.append ("\n");
    // Recommand image size for ChoiceGroup icons
    form.append ("ChoiceGroup icon size: " +
      display.getBestImageWidth(Display.CHOICE_GROUP_ELEMENT)
      + " x " +
      display.getBestImageHeight(Display.CHOICE_GROUP_ELEMENT));
    form.append ("\n");
    // Recommended image size for icons in a list element
    form.append ("List element icon size: " +
      display.getBestImageWidth(Display.LIST_ELEMENT)
      + " x " +
      display.getBestImageHeight(Display.LIST_ELEMENT));
    form.append ("\n");
    // Recommended image size for alert icons
    form.append ("Alert icon size: " +
      display.getBestImageWidth(Display.ALERT)
      + " x " +
      display.getBestImageHeight(Display.ALERT));
    form.append ("\n");
    // The background color in 0xRRGGBB format
    form.append ("Background color: " +
      display.getColor(Display.COLOR_BACKGROUND));
    form.append ("\n");
    // The foreground color in 0xRRGGBB format
    form.append ("Foreground color: " +
      display.getColor(Display.COLOR_FOREGROUND));
    form.append ("\n");
  }

  private void getDisplayableInfo (Form form) {
    form.append ("Height: " + form.getHeight());
    form.append ("\n");
    form.append ("Width: " + form.getWidth());
    form.append ("\n");
  }


}
