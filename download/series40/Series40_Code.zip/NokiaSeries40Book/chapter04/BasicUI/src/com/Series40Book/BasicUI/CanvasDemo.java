package com.Series40Book.BasicUI;

import javax.microedition.lcdui.*;


public class CanvasDemo extends Canvas
             implements CommandListener {

  private CommandListener comm;
  private Image img;
  private Font font;
  public int currentPosX, currentPosY;
  public int width, height;

  public CanvasDemo (CommandListener c) {
    comm = c;
    width = getWidth ();
    height = getHeight ();
    // The current cursor position for the text
    currentPosX = width / 2;
    currentPosY = height / 2;
    // The text font
    font = Font.getFont(Font.FACE_PROPORTIONAL,
            Font.STYLE_BOLD, Font.SIZE_LARGE);

    // setFullScreenMode (true);
    setCommandListener (this);

    try {
      img = Image.createImage("/" + "telescope.png");
    } catch (Exception e) {
      e.printStackTrace ();
      img = null;
    }
  }


  public void commandAction (Command c, Displayable d) {
    comm.commandAction(c, d);
  }

  public void paint (Graphics g) {
    // Fill a white background
    g.setColor(0xffffff);
    g.fillRect(0,  0, width, height);
    // Set text color
    g.setColor(0x000000);
    g.drawImage (img, width / 2, height / 2,
            Graphics.HCENTER | Graphics.VCENTER);
    g.setFont (font);
    g.setColor (255, 0, 0);
    g.drawString ("Telescope", currentPosX, currentPosY,
            Graphics.BASELINE | Graphics.HCENTER);
  }

  // Move the text around when the game keys are pressed
  public void keyPressed (int keyCode) {
    int gameCode = getGameAction (keyCode);
    if (gameCode == UP) {
      currentPosY -= 10;
      repaint ();
    } else if (gameCode == DOWN) {
      currentPosY += 10;
      repaint ();
    } else if (gameCode == LEFT) {
      currentPosX -= 10;
      repaint ();
    } else if (gameCode == RIGHT) {
      currentPosX += 10;
      repaint ();
    } else {
      super.keyPressed(keyCode);
    }
  }

}
