package com.Series40Book.BasicUI;

import javax.microedition.lcdui.*;


public class ImageButtonItem extends CustomItem {

  private Image img;
  public TextField textField;

  public ImageButtonItem () {
    super ("");

    try {
      img = Image.createImage("/echo1.png");
    } catch (Exception e) {
      e.printStackTrace ();
      img = null;
    }
  }

  public int getMinContentWidth () {
    return 108;
  }

  public int getMinContentHeight () {
    return 33;
  }

  public int getPrefContentWidth (int width) {
    return getMinContentWidth ();
  }

  public int getPrefContentHeight (int height) {
    return getMinContentHeight ();
  }

  protected boolean traverse (int dir, int w, int h,
                              int [] visRect_inout) {
    try {
      img = Image.createImage("/echo2.png");
    } catch (Exception e) {
      e.printStackTrace ();
      // do nothing
    }
    repaint ();
    return false;
  }

  protected void traverseOut () {
    try {
      img = Image.createImage("/echo1.png");
    } catch (Exception e) {
      e.printStackTrace ();
      // do nothing
    }
    repaint ();
  }

  public void paint (Graphics g, int w, int h) {
    g.drawImage (img, w / 2, h / 2,
            Graphics.HCENTER | Graphics.VCENTER);
  }

  public void keyPressed (int keyCode) {
    int gameCode = getGameAction (keyCode);

    if (gameCode == Canvas.FIRE) {

      Display display = DriverMidlet.display;
      Alert alert = new Alert ("Your text is",
              textField.getString(),
              null, AlertType.ALARM);

      alert.setTimeout(Alert.FOREVER);
      display.setCurrent (alert);

    } else {
      super.keyPressed(keyCode);
    }
  }

}