package com.Series40Book.BasicUI;

import javax.microedition.lcdui.*;


public class ItemCommandDemo extends Form
                implements CommandListener {

  private CommandListener comm;
  private TextField textField;
  private StringItem si;
  private Command echo;

  public ItemCommandDemo (CommandListener c) {
    super ("Item Command");
    comm = c;

    textField = new TextField("Your message",
            "", 20, TextField.ANY);
    append (textField);

    echo = new Command ("Echo", Command.ITEM, 1);
    EchoListener el = new EchoListener ();

    // The PLAIN appearance mode will automatically
    // be converted to HYPERLINK if there is an
    // item Command associated with this item.
    si = new StringItem("", "Echo Link", Item.PLAIN);
    si.setLayout(Item.LAYOUT_CENTER);
    si.addCommand (echo);
    si.setDefaultCommand(echo);
    si.setItemCommandListener (el);
    append (si);

    si = new StringItem("", "Echo Button", Item.BUTTON);
    si.setLayout(Item.LAYOUT_CENTER);
    si.addCommand (echo);
    si.setDefaultCommand(echo);
    si.setItemCommandListener (el);
    append (si);

    setCommandListener (this);
  }

  public void commandAction (Command c, Displayable d) {
    comm.commandAction(c, d);
  }

  class EchoListener implements ItemCommandListener {

    public void commandAction (Command c, Item i) {
      if (c == echo) {
        Display display = DriverMidlet.display;
        Alert alert = new Alert ("Your text is",
            textField.getString(),
            null, AlertType.ALARM);
        alert.setTimeout(Alert.FOREVER);
        display.setCurrent (alert);
      }
    }
  }

}
