package com.Series40Book.midp.view;

import com.Series40Book.midp.controller.*;
import javax.microedition.lcdui.*;

public class ResultUI extends Form
         implements CommandListener {

  private Command doneCommand;

  public ResultUI () {
    super("Report");

    doneCommand = UIController.doneCommand;
    addCommand(doneCommand);
    setCommandListener(this);
  }

  public void setStatus (int correctNum, int wrongNum,
                                           long time) {
    int total = correctNum + wrongNum;
    append("You get " + correctNum +
           " correct answers out of " +
           total + " total questions\n");
    append("The total time is " + time + " seconds");
  }

  public void commandAction(Command c, Displayable s) {
    try {
      if (c == doneCommand) {
        UIController.resume();
      }
    } catch (Exception e) {
      e.printStackTrace ();
    }
  }
}