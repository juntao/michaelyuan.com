package com.Series40Book.midp.view;

import com.Series40Book.midp.controller.*;
import javax.microedition.lcdui.*;


public class ShowAnswerUI extends Form
             implements CommandListener {

  private Command continueCommand;

  public ShowAnswerUI () {
    super ("Answer");
    continueCommand =
        new Command("Continue", Command.SCREEN, 1);
    addCommand(continueCommand);
    setCommandListener(this);
  }

  public void setStatus (boolean correct, String hint) {
    int n = size ();
    for (int i = 0; i < n; i++) {
      delete (i);
    }

    String s;
    if (correct) {
      s = "Correct!";
    } else {
      s = "Incorrect!";
    }

    append (new StringItem(s, hint));
  }

  public void commandAction (Command c, Displayable s) {
    try {
      if (c == continueCommand) {
        UIController.nextQuestion();
      }
    } catch (Exception e) {
      e.printStackTrace();
    }
  }
}
