package com.Series40Book.midp.model.questions;

import java.io.*;

/**
 * The trivia question value object
 */
class TriviaQuestion {
  public String questionId;
  public String question;
  public String [] choices;
  public String answerHint;
  public int answerId;
  public byte [] image;
  public byte [] sound;
  public boolean sendAnswer;

  public TriviaQuestion (String qid, String q,
                         String [] c, String ah, int ai,
                         byte [] i, byte [] s) {
    questionId = qid;
    question = q;
    choices = c;
    answerHint = ah;
    answerId = ai;
    image = i;
    sound =s;
    sendAnswer = false;
  }

  public TriviaQuestion () {

    questionId = null;
    question = "";
    choices = new String [0];
    sendAnswer = false;
    answerHint = "";
    answerId = -1;
    image = null;
    sound =null;

  }

  public byte [] persist () throws Exception {
    byte [] result = new byte [0];

    ByteArrayOutputStream baos = null;
    DataOutputStream dos = null;

    try {
      baos = new ByteArrayOutputStream ();
      dos = new DataOutputStream (baos);
      persist(dos);
      dos.flush ();
      baos.flush ();
      result = baos.toByteArray();

      dos.close ();
      baos.close ();
    } finally {
      try {
        if (dos != null) dos.close();
        if (baos != null) baos.close ();
      } catch (Exception e) { }
    }
    return result;
  }

  public void persist (DataOutputStream dos)
                           throws Exception {
    if (questionId != null) {
      // There is nothing to persist
      // if the questionId is missing
      dos.writeUTF(questionId);
      dos.writeUTF(question);
      dos.writeInt(choices.length);
      for (int i = 0; i < choices.length; i++) {
        dos.writeUTF(choices[i]);
      }

      if (image != null) {
        dos.writeBoolean(true);
        dos.writeInt(image.length);
        dos.write(image, 0, image.length);
      } else {
        dos.writeBoolean(false);
      }

      if (sound != null) {
        dos.writeBoolean(true);
        dos.writeInt(sound.length);
        dos.write(sound, 0, sound.length);
      } else {
        dos.writeBoolean(false);
      }

      dos.writeBoolean (sendAnswer);
      if (sendAnswer) {
        dos.writeUTF(answerHint);
        dos.writeInt(answerId);
      }
    }
  }

  public void load (byte [] entry) throws Exception {
    ByteArrayInputStream bais = null;
    DataInputStream dis = null;

    try {
      bais = new ByteArrayInputStream (entry);
      dis = new DataInputStream (bais);
      load (dis);

      dis.close ();
      bais.close ();
    } finally {
      try {
        if (dis != null) dis.close();
        if (bais != null) bais.close ();
      } catch (Exception e) { }
    }
  }

  public void load (DataInputStream dis)
                          throws Exception {

    questionId = dis.readUTF();
    question = dis.readUTF();
    int numChoices = dis.readInt();
    choices = new String[numChoices];
    for (int i = 0; i < numChoices; i++) {
      choices[i] = dis.readUTF();
    }
    boolean hasImage = dis.readBoolean ();
    if (hasImage) {
      int size = dis.readInt();
      image = new byte [size];
      dis.readFully(image);
    } else {
      image = null;
    }
    boolean hasMusic = dis.readBoolean ();
    if (hasMusic) {
      int size = dis.readInt();
      sound = new byte [size];
      dis.readFully(sound);
    } else {
      sound = null;
    }
    sendAnswer = dis.readBoolean ();
    if (sendAnswer) {
      answerHint = dis.readUTF();
      answerId = dis.readInt();
    } else {
      answerHint = "";
      answerId = -1;
    }
  }

}
