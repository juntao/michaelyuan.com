package com.Series40Book.midp.view;

import javax.microedition.lcdui.*;

/**
 * Each package needs to extend this class to ScrollCanvas that
 * provides custom default behaviors for event/key handlers.
 *
 * Real screen UI classes extends the ScrollCanvas class
 * to provide screen specfic drawings and buttons
 */
public abstract class ScrollCanvas extends Canvas
        implements CommandListener {

  // The upper left corner coord of the virtual canvas
  // They are typically both negative values
  protected int startX, startY;
  protected int w, h;

  // The displayed part of the virtual canvas is
  // always the area between [0,0] to [w,h]

  public ScrollCanvas () {
    startX = 0;
    startY = 0;

    w = getWidth ();
    h = getHeight ();
  }


  public void commandAction(Command c, Displayable s) {

    // Handle commands that are common to
    // every ScrollCanvas.
    // By default, there is none
    //
    // repaint ();
  }


  protected void keyReleased (int keyCode) {
    switch (getGameAction(keyCode)) {
      case UP:    startY += h / 2; break;
      case DOWN:  startY -= h / 2; break;
      case LEFT:  startX += w / 2; break;
      case RIGHT: startX -= w / 2; break;
      default: break;
    }
    // Do not scroll beyond the top
    if (startY > 0) startY = 0;
    // Do not scroll beyond the left edge
    if (startX > 0) startX = 0;
    repaint ();
  }

}
