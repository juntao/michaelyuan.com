package com.Series40Book.midp.controller;

import javax.microedition.lcdui.*;

public class Stack {

  private Displayable [] screens;

  public Stack () {
    screens = new Displayable [3];
  }
  
  public void push (Displayable d) {
    screens[2] = screens[1];
    screens[1] = screens[0];
    screens[0] = d;
  }

  public Displayable pop () {
    Displayable result = screens[0];
    screens[0] = screens[1];
    screens[1] = screens[2];
    screens[2] = null;
    return result;
  }
}
