package com.Series40Book.midp.view;

import com.Series40Book.midp.controller.UIController;

import javax.microedition.lcdui.*;

public class SMSStatusUI extends Form implements CommandListener {

  private Command backCommand;

  public SMSStatusUI () {
    super("Status");
    backCommand = UIController.backCommand;
    addCommand(backCommand);
    setCommandListener(this);
  }

  // Construct the UI
  public void setStatus (String status) {
    int n = size ();
    for (int i = 0; i < n; i++) {
      delete (i);
    }
    
    append(status);
  }

  public void commandAction(Command c, Displayable s) {
    try {
      if (c == backCommand) {
        UIController.showBack ();
      }
    } catch (Exception e) {
      e.printStackTrace();
    }
  }
}
