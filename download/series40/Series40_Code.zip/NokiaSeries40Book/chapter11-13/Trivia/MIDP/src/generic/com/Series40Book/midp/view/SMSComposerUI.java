package com.Series40Book.midp.view;

import com.Series40Book.midp.controller.*;
import javax.microedition.lcdui.*;

/**
 * Created by IntelliJ IDEA.
 */
public class SMSComposerUI extends Form implements CommandListener {

  private TextField phoneNumber, message;
  private Command goCommand;
  private Command backCommand;

  public SMSComposerUI () {
    super("Message");
    phoneNumber =
            new TextField("Phone Number", "", 20, TextField.NUMERIC);
    message = new TextField("Message", "", 128, TextField.ANY);
    append(phoneNumber);
    append(message);

    goCommand = UIController.goCommand;
    backCommand = UIController.backCommand;
    addCommand(goCommand);
    addCommand(backCommand);
    setCommandListener(this);
  }

  // Construct the UI
  public void setStatus () {
    // nothing
  }

  public void commandAction(Command c, Displayable s) {
    try {
      if (c == goCommand) {
        // The SMSStatusUI's back button returns to the InboxUI screen
        UIController.sendMessage(phoneNumber.getString(),
                                 message.getString());
      } else if (c == backCommand) {
        UIController.showBack ();
      }
    } catch (Exception e) {
      e.printStackTrace();
    }
  }
}
