package com.Series40Book.midp.model;

/**
 * Maintains time for each session
 *
 */
public class TheTimer {

  static private long currentCount;
  static private long startTime;
  static private boolean pauseFlag = false;

  static public void start () {
    startTime = System.currentTimeMillis();
    currentCount = 0;
  }

  static public void pause () {
    if (!pauseFlag) {
      long rightNow = System.currentTimeMillis();
      currentCount += (rightNow - startTime);
      startTime = rightNow;
      pauseFlag = true;
    }
  }

  static public void resume () {
    if (pauseFlag) {
      startTime = System.currentTimeMillis();
      pauseFlag = false;
    }
  }

  static public long report () {
    if (pauseFlag) {
      return currentCount;
    } else {
      long rightNow = System.currentTimeMillis();
      currentCount += (rightNow - startTime);
      startTime = rightNow;
      return currentCount;
    }
  }

}
