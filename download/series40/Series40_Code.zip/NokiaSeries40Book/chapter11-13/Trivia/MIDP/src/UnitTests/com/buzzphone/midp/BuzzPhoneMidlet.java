package com.buzzphone.midp;

import j2meunit.midletui.TestRunner;

/**
 * The Unit test entry midlet
 */
public class BuzzPhoneMidlet extends TestRunner {

  public BuzzPhoneMidlet () {
  }

  protected void startApp() {
    start(new String [] {"com.buzzphone.midp.tests.PrefStoreTest"});
  }

  protected void destroyApp(boolean unconditional) {
    // do nothing
  }

  protected void pauseApp() {
    // do nothing
  }

  public void exit () {
  }

}
