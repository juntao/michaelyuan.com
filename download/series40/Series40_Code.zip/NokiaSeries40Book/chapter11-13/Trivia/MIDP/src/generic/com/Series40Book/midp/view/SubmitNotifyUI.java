package com.Series40Book.midp.view;

import javax.microedition.lcdui.*;
import com.Series40Book.midp.controller.*;

public class SubmitNotifyUI extends List
                 implements CommandListener {

  private Command exitCommand;
  private Command goCommand;

  public SubmitNotifyUI () {
    super("Submt answers?", List.IMPLICIT);

    goCommand = UIController.goCommand;
    addCommand(goCommand);

    //#ifndef S60
    {
      exitCommand = UIController.exitCommand;
      addCommand (exitCommand);
    }
    //#endif

    setCommandListener(this);

    append("Submit now", null);
    append("Submit later", null);
    append("Start over", null);
  }

  // This UI screen is always the same
  public void setStatus () {
    // This empty method is here for compatibility reasons
  }

  public void commandAction(Command c, Displayable s) {
    try {
      if (c == exitCommand) {
        UIController.exit();
      } else if (c == goCommand || c == SELECT_COMMAND) {
        if (getSelectedIndex() == 0) {
          UIController.submit();
        } else if (getSelectedIndex() == 1) {
          UIController.needSubmit = true;
          UIController.resume();
        } else if (getSelectedIndex() == 2) {
          UIController.restartQuestion();
        }
      }
    } catch (Exception e) {
      e.printStackTrace ();
    }
  }

}
