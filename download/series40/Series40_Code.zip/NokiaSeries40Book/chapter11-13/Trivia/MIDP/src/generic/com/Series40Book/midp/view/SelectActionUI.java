package com.Series40Book.midp.view;

import com.Series40Book.midp.controller.*;
import javax.microedition.lcdui.*;
import java.io.IOException;

/**
 * Use background and button images instead of simple lists
 */
public class SelectActionUI extends Canvas implements CommandListener {

  private final static String [] iconFiles = {
    "/NewSess.png",
    "/ResumeSess.png",
    "/History.png",
    "/Pref.png",
    "/Submit.png",
    "/Google.png",
    "/Chat.png"
  };
  private final static String [] iconDescriptions = {
    "New Session",
    "Resume Session",
    "History",
    "Preference",
    "Submit results",
    "Google",
    "Chat"
  };
  private final static int newSessState = 0;
  private final static int resumeSessState = 1;
  private final static int historyState = 2;
  private final static int prefState = 3;
  private final static int submitState = 4;
  private final static int googleState = 5;
  private final static int chatState = 6;
  private Image [] icons;

  private final static String backgroundFile = "/Background.png";
  private Image background;
  private static int width, height;

  private static boolean isPaused;
  private static boolean needSubmit;
  private static int state;
  private Command exitCommand;
  private Command goCommand;


  public SelectActionUI () {
    state = 0;
    width = getWidth ();
    height = getHeight ();

    // We construct all images at once to speed things up later.
    // But the trade off is more memory usage. If memory is a
    // concern, you can build individual icons inside the "paint()"
    // method.
    icons = new Image[iconFiles.length];
    for (int i = 0; i < iconFiles.length; i++) {
      try {
        icons[i] = Image.createImage(iconFiles[i]);
      } catch (IOException e) {
        e.printStackTrace ();
        icons[i] = Image.createImage(40, 40);
      }
    }

    try {
      background = Image.createImage(backgroundFile);
    } catch (IOException e) {
      e.printStackTrace ();
      background = Image.createImage(128, 128);
    }

    goCommand = UIController.goCommand;
    addCommand(goCommand);

    //#ifndef S60
    {
      exitCommand = UIController.exitCommand;
      addCommand (exitCommand);
    }
    //#endif

    setCommandListener(this);
  }

  public void paint (Graphics g) {

    // Fill the canvas with white background in case the
    // background image does not match the canvas size
    g.setColor(255, 255, 255);
    g.fillRect(0, 0, width, height);
    // Draw the background image
    g.drawImage(background, width/2, height/2,
              Graphics.VCENTER|Graphics.HCENTER);

    // Draw the action icon
    g.drawImage(icons[state], width/2, height/4,
                Graphics.VCENTER|Graphics.HCENTER);

    // Draw the explain text in highlighted URL style
    g.setColor(0, 0, 255);
    Font font = Font.getFont(Font.FACE_PROPORTIONAL,
                             Font.STYLE_BOLD|Font.STYLE_UNDERLINED,
                             Font.SIZE_MEDIUM);
    g.setFont(font);
    g.drawString(iconDescriptions[state], width/2, height/4 * 3,
                 Graphics.TOP|Graphics.HCENTER);
  }

  protected void keyReleased (int keyCode) {
    int actionCode = getGameAction(keyCode);
    if (actionCode == UP | actionCode == LEFT) {
      boolean valid = false;
      while (!valid) {
        state--;
        if (state < 0) {
          state = iconFiles.length - 1;
        }
        valid = isValidState(state);
      }
      repaint ();
    } else if (actionCode == DOWN | actionCode == RIGHT) {
      boolean valid = false;
      while (!valid) {
        state++;
        if (state > iconFiles.length - 1) {
          state = 0;
        }
        valid = isValidState(state);
      }
      repaint ();
    } else if (actionCode == FIRE) {
      takeAction ();
    }
  }

  public void setStatus (boolean p, boolean s) {
    isPaused = p;
    needSubmit = s;
    if (!isValidState(state)) {
      state = 0;
    }
  }

  public void commandAction(Command c, Displayable s) {
    if (c == exitCommand) {
      UIController.exit();
    } else if (c == goCommand) {
      takeAction ();
    }
  }

  private void takeAction () {
    try {
      if (state == resumeSessState) {
        UIController.resumeQuestion();
      } else if (state == newSessState) {
        UIController.download();
      } else if (state == googleState) {
        UIController.showGoogleQuery(this);
      } else if (state == historyState) {
        UIController.showReport();
      } else if (state == prefState) {
        UIController.showPref();
      } else if (state == submitState) {
        UIController.submit();
      } else if (state == chatState) {
        //#if WMA
        {
          UIController.firstMessage(this);
        }
        //#endif
      }
    } catch (Exception e) {
      Alert a = new Alert ("Error", "Cannot complete task",
              null, AlertType.ERROR);
      a.setTimeout(Alert.FOREVER);
      UIController.display.setCurrent(a, this);
    }
  }

  private boolean isValidState (int state) {
    boolean result = true;

    if ((!isPaused) && (state == resumeSessState)) {
      result = false;
    }
    if ((!needSubmit) && (state == submitState)) {
      result = false;
    }
    //#if !WMA
    {
      if ((state == chatState)) {
        result = false;
      }
    }
    //#else
    {
      if ((state == chatState)) {
        result = true;
      }
    }
    //#endif

    return result;
  }

}