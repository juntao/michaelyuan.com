package com.Series40Book.midp.controller;

public interface WorkerRunnable extends Runnable {

  void setWait (WaitScreen w);
  void updateWaitStatus (String mesg);
  void stop ();
}