package com.Series40Book.midp.controller;

/**
 * The WorkerThread template class
 */
public abstract class WorkerThread
          implements WorkerRunnable {

  public WaitScreen wait;
  protected int count = 0;
  protected boolean stopped = false;

  public WorkerThread () {
  }

  public void setWait (WaitScreen w) {
    wait = w;
  }

  public void updateWaitStatus (String mesg) {
    count++;
    wait.message = mesg;
    wait.setCount(count);
  }

}
