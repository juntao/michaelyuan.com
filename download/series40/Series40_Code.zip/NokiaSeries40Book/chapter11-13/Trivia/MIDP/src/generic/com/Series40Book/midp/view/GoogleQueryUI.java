package com.Series40Book.midp.view;

import com.Series40Book.midp.controller.*;
import javax.microedition.lcdui.*;


public class GoogleQueryUI extends TextBox
                  implements CommandListener {

  private Command goCommand;
  private Command backCommand;

  public GoogleQueryUI () {
    super("Research", "", 1024, TextField.ANY);
    goCommand = UIController.goCommand;
    backCommand = UIController.backCommand;
    addCommand(goCommand);
    addCommand(backCommand);
    setCommandListener(this);
  }

  // Construct the UI
  public void setStatus (String q) {
    if ( q == null ) {
      q = "";
    }
    setString(q);
  }

  public void commandAction(Command c, Displayable s) {
    try {
      if (c == goCommand) {
        UIController.getGoogleResults(getString(), this);
      } else if (c == backCommand) {
        UIController.showBack();
      }
    } catch (Exception e) {
      e.printStackTrace();
    }
  }
}
