package com.Series40Book.midp;

import javax.microedition.midlet.*;
import com.Series40Book.midp.model.*;
import com.Series40Book.midp.controller.*;


/**
 * The entry Midlet
 *
 */
public class TriviaMidlet extends MIDlet {

  public TriviaMidlet () {
    TheTimer.start();
  }

  protected void startApp() {
    try {

      TheTimer.resume();

      if (UIController.isPaused == false) {
        UIController.init(this);
      } else {
        UIController.isPaused = false;
        UIController.resume();
      }

    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  protected void destroyApp(boolean unconditional) {
    try {

    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  protected void pauseApp() {
    try {
      UIController.isPaused = true;
      TheTimer.pause();
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

  public void exit () {
    destroyApp(false);
    notifyDestroyed();
  }

}
