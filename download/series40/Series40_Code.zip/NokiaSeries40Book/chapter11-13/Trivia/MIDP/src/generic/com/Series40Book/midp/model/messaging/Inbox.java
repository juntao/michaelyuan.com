package com.Series40Book.midp.model.messaging;

/**
 * Created by IntelliJ IDEA.
 */
public interface Inbox {

  public void setupListener (String port) throws Exception;
  public String firstMessage () throws Exception;
  public String nextMessage () throws Exception;
  public void deleteMessage () throws Exception;
  public void cleanUp () throws Exception;

}
