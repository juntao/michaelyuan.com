package com.Series40Book.midp.view;

/**
 * Created by IntelliJ IDEA.
 */
public class SoundPlayerImpl implements SoundPlayer {

  public void playSound (byte [] sound) {

  }

}