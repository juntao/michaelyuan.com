package com.buzzphone.midp.tests;

import j2meunit.framework.*;
import com.buzzphone.midp.model.PrefStore;

/**
 * The preference store test case
 */

public class PrefStoreTest extends TestCase {

  public PrefStoreTest () {
  }


  public PrefStoreTest (String sTestName, TestMethod rTestMethod) {
    super(sTestName, rTestMethod);
  }


  public Test suite() {
    TestSuite aSuite = new TestSuite();

    aSuite.addTest(
            new PrefStoreTest("testSave",
                    new TestMethod() {
                      public void run(TestCase tc) {
                        ((PrefStoreTest) tc).testSave();
                      }
                    }
            ));
    aSuite.addTest(
            new PrefStoreTest("testRestore",
                    new TestMethod() {
                      public void run(TestCase tc) {
                        ((PrefStoreTest) tc).testRestore();
                      }
                    }
            ));

    return aSuite;
  }

  public void testSave() {
    try {
      PrefStore pref = PrefStore.getInstance();
      pref.category = "music02";
      pref.googleIsPhrase = true;
      pref.googleResultsNum = 10;
      pref.googleTextMargin = 100;
      pref.save ();

    } catch (Exception e) {
      assertTrue ("An exception was thrown during saving:", false);
      e.printStackTrace ();
    }
  }

  public void testRestore () {
    try {
      PrefStore pref = PrefStore.getInstance ();
      pref.category = "mmmmm";
      pref.googleIsPhrase = false;
      pref.googleResultsNum = 2;
      pref.googleTextMargin = 1000;
      pref.restore ();

      assertEquals(pref.category, "music02");
      assertTrue((pref.googleIsPhrase == true));
      assertTrue((pref.googleResultsNum == 10));
      assertTrue((pref.googleTextMargin == 100));

    } catch (Exception e) {
      assertTrue ("An exception was thrown during restoring:", false);
      e.printStackTrace ();
    }
  }

}

