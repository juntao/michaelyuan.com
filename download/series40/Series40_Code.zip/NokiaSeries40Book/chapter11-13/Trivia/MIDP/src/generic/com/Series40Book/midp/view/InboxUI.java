package com.Series40Book.midp.view;

import com.Series40Book.midp.controller.*;
import javax.microedition.lcdui.*;

/**
 * Created by IntelliJ IDEA.
 */
public class InboxUI extends Form 
        implements CommandListener {

  private Command nextCommand;
  private Command deleteCommand;
  private Command backCommand;
  private Command sendSMSCommand;

  public InboxUI () {
    super("Message");
    nextCommand = UIController.nextCommand;
    deleteCommand =
        new Command("Delete", Command.SCREEN, 1);
    backCommand = UIController.backCommand;
    sendSMSCommand =
        new Command("Send SMS", Command.SCREEN, 1);


    addCommand(sendSMSCommand);
    addCommand(nextCommand);
    addCommand(deleteCommand);
    addCommand(backCommand);

    setCommandListener(this);
  }

  // Construct the UI
  // TODO: add incoming phone numbers
  public void setStatus (String mesg) {

    int n = size ();
    for (int i = 0; i < n; i++) {
      delete (i);
    }

    if (mesg == null || "".equals(mesg)) {
      append("No message");
    } else {
      append(mesg);
    }
  }

  public void commandAction(Command c, Displayable s) {
    try {
      if (c == nextCommand) {
        UIController.nextMessage();
      } else if (c == deleteCommand) {
        UIController.deleteMessage();
      } else if (c == backCommand) {
        UIController.exitMessage();
      } else if (c == sendSMSCommand) {
        UIController.showSMSComposer(this);
      }
    } catch (Exception e) {
      e.printStackTrace();
    }
  }
}
