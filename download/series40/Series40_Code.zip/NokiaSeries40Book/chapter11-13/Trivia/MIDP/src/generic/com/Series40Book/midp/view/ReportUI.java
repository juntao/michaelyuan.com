package com.Series40Book.midp.view;

import com.Series40Book.midp.controller.*;
import javax.microedition.lcdui.*;

public class ReportUI extends ScrollCanvas {

  private Command doneCommand;
  private Command clearCommand;
  private Command syncCommand;
  String [] corr, wrong, time;

  private Font headfont =
      Font.getFont(Font.FACE_PROPORTIONAL,
            Font.STYLE_BOLD, Font.SIZE_MEDIUM);
  private Font bodyfont =
      Font.getFont(Font.FACE_PROPORTIONAL,
            Font.STYLE_PLAIN, Font.SIZE_MEDIUM);

  public ReportUI () {
    doneCommand = UIController.doneCommand;
    clearCommand =
        new Command("Clear", Command.SCREEN,  2);
    syncCommand =
        new Command("Sync", Command.SCREEN, 2);

    addCommand(doneCommand);
    addCommand(clearCommand);
    addCommand(syncCommand);
    setCommandListener(this);
  }

  public void setStatus (int [] c, int [] w, long [] t) {
    int size = c.length;
    corr = new String [size];
    wrong = new String [size];
    time = new String [size];

    for (int i = 0; i < size; i++) {
      corr[i] = Integer.toString(c[i]);
      wrong[i] = Integer.toString(w[i]);
      time[i] = Long.toString(t[i]);
    }

    repaint ();
  }

  protected void paint (Graphics g) {
    g.setColor(0xffffff);
    g.fillRect(0,  0, w, h);
    g.setColor(0x000000);

    int x = startX;
    int y = startY;

    g.setFont (headfont);
    y += headfont.getHeight() + 5;
    g.drawString ("Correct", x, y,
            Graphics.BASELINE | Graphics.LEFT);
    g.drawString ("Wrong", x + w/2, y,
            Graphics.BASELINE | Graphics.HCENTER);
    g.drawString ("Time", x + w, y,
            Graphics.BASELINE | Graphics.RIGHT);

    g.setFont (bodyfont);
    for (int i = 0; i < corr.length; i++) {
      y += bodyfont.getHeight() + 5;
      g.drawString (corr[i], x, y,
              Graphics.BASELINE | Graphics.LEFT);
      g.drawString (wrong[i], x + w/2, y,
              Graphics.BASELINE | Graphics.HCENTER);
      g.drawString (time[i] + " s", x + w, y,
              Graphics.BASELINE | Graphics.RIGHT);
    }
  }

  public void commandAction(Command c, Displayable s) {
    try {
      if (c == doneCommand) {
        UIController.resume();
      } else if (c == clearCommand) {
        UIController.clearHistory ();
      } else if (c == syncCommand) {
        UIController.synchronize ();
      }
    } catch (Exception e) {
      e.printStackTrace ();
    }
  }
}


/*
public class ReportUI extends Form implements CommandListener {

  private Command doneCommand;
  private Command clearCommand;
  private Command syncCommand;

  public ReportUI () {
    super("Report");

    doneCommand = UIController.doneCommand;
    clearCommand =
        new Command("Clear", Command.SCREEN,  2);
    syncCommand =
        new Command("Sync", Command.SCREEN, 2);

    addCommand(doneCommand);
    addCommand(clearCommand);
    addCommand(syncCommand);
    setCommandListener(this);
  }

  public void setStatus (int [] corrHistory,
                         int [] wrongHistory,
                         long [] timeHistory) {
    int n = size ();
    for (int i = 0; i < n; i++) {
      delete (i);
    }

    append("Correct  Wrong  Time \n");
    for (int i = 0; i < corrHistory.length; i++) {
      append(corrHistory[i] + "       " +
             wrongHistory[i] + "      " +
             timeHistory[i] + "s \n");
    }
  }

  public void setStatus (int correctNum, int wrongNum,
                                           long time) {
    int total = correctNum + wrongNum;
    append("You get " + correctNum +
           " correct answers out of " +
           total + " total questions\n");
    append("The total time is " + time + " seconds");
  }

  public void commandAction(Command c, Displayable s) {
    try {
      if (c == doneCommand) {
        UIController.resume();
      } else if (c == clearCommand) {
        UIController.clearHistory ();
      } else if (c == syncCommand) {
        UIController.synchronize ();
      }
    } catch (Exception e) {
      e.printStackTrace ();
    }
  }
}
*/
