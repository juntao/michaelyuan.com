package com.Series40Book.midp.model;

/**
 * Pre-defined constants for network operations
 */
public class OpCodes {

  public static int DOWNLOAD = 1;
  public static int SUBMIT = 2;
  public static int GOOGLE = 3;
  public static int SYNC01 = 4;
  public static int SYNC02 = 5;

}
