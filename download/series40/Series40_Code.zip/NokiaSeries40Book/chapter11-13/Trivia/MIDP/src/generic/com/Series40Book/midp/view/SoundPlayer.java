package com.Series40Book.midp.view;


public interface SoundPlayer {
  public void playSound (byte [] sound);
}
