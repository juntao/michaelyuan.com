package com.Series40Book.midp.view;

import com.Series40Book.midp.controller.*;
import javax.microedition.lcdui.*;


public class GoogleResultUI extends Form
              implements CommandListener {

  private Command backCommand;

  public GoogleResultUI () {
    super ("Google Results");
    backCommand = UIController.backCommand;
    addCommand(backCommand);
    setCommandListener(this);
  }

  // Construct the UI
  public void setStatus (String spellSugg, String [] urls,
                         String [] snippets) {
    // MIDP2 only: deleteAll ();

    int n = size ();
    for (int i = 0; i < n; i++) {
      delete (i);
    }
    append(new StringItem("Spell Suggestion", spellSugg));
    for (int i = 0; i < urls.length; i++) {
      append (new StringItem (urls[i], snippets[i]));
    }

  }

  public void commandAction (Command c, Displayable s) {
    try {
      if (c == backCommand) {
        UIController.showBack();
      }
    } catch (Exception e) {
      e.printStackTrace();
    }
  }

}
