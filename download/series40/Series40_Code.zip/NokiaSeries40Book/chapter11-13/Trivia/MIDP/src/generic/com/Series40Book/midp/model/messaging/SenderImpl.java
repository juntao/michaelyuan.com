package com.Series40Book.midp.model.messaging;

import javax.wireless.messaging.*;
import javax.microedition.io.*;

/**
 * Created by IntelliJ IDEA.
 */

public class SenderImpl implements Sender {

  public String port;

  public SenderImpl () {
  }

  public void setPort (String port) {
    this.port = port;
  }

  public void send (String addr, String mesg) throws Exception {

    if (port == null) {
      addr = "sms://" + addr;
    } else {
      addr = "sms://+" + addr + ":" + port;
    }

    MessageConnection conn =
          (MessageConnection) Connector.open(addr);
    TextMessage msg =
          (TextMessage) conn.newMessage(MessageConnection.TEXT_MESSAGE);
    msg.setPayloadText( mesg );
    conn.send( msg );
    conn.close ();
  }

}