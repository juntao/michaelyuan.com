package com.Series40Book.midp.view;

import com.Series40Book.midp.controller.*;
import javax.microedition.lcdui.*;


/**
 * The preference screen
 */
public class PrefUI extends Form implements CommandListener {

  private Command doneCommand;
  private Command abortCommand;

  private TextField cField;
  private TextField gRField;
  private TextField gTField;
  private ChoiceGroup gIGroup;

  public PrefUI () {
    super("Preference");
    doneCommand = UIController.doneCommand;
    abortCommand = new Command ("Abort", Command.EXIT, 2);
    addCommand(doneCommand);
    addCommand(abortCommand);
    setCommandListener(this);

    cField =
        new TextField("Category", "", 20, TextField.ANY);
    gRField = new TextField("Num of Google Results",
        "3", 4, TextField.NUMERIC);
    gTField = new TextField("Google text size",
        "50", 4, TextField.NUMERIC);

    gIGroup = new ChoiceGroup("Search complete phrases?",
        Choice.EXCLUSIVE);
    gIGroup.append("yes", null);
    gIGroup.append("no", null);

    append(cField);
    append(gRField);
    append(gTField);
    append(gIGroup);
  }

  public void setStatus (String category,
          int googleResultsNum, int googleTextMargin,
          boolean googleIsPhrase) {
    cField.setString(category);
    gRField.setString(Integer.toString(googleResultsNum));
    gTField.setString(Integer.toString(googleTextMargin));

    if (googleIsPhrase) {
      gIGroup.setSelectedIndex(0, true);
    } else {
      gIGroup.setSelectedIndex(1, true);
    }
  }

  public void commandAction(Command c, Displayable s) {
    try {
      if (c == doneCommand) {
        boolean tmp;
        if (gIGroup.getSelectedIndex () == 0) {
          tmp = true;
        } else {
          tmp = false;
        }
        UIController.setPref( cField.getString(),
                Integer.parseInt(gRField.getString()),
                Integer.parseInt(gTField.getString()),
                tmp);

      } else if (c == abortCommand) {
        UIController.resume ();
      }
    } catch (Exception e) {
      e.printStackTrace ();
    }
  }

}
