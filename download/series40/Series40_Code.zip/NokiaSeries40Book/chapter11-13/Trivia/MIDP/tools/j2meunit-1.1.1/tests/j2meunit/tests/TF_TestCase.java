//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
// This file is part of J2MEUnit, a Java 2 Micro Edition unit testing framework.
//
// J2MEUnit is free software distributed under the Common Public License (CPL).
// It may be redistributed and/or modified under the terms of the CPL. You 
// should have received a copy of the license along with J2MEUnit. It is also 
// available from the website of the Open Source Initiative at 
// http://www.opensource.org.
//
// J2MEUnit is distributed in the hope that it will be useful, but WITHOUT ANY 
// WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS 
// FOR A PARTICULAR PURPOSE.
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
package j2meunit.tests;

import j2meunit.framework.*;

/********************************************************************
 * Test case to test the framework.
 */
public class TF_TestCase extends TestCase
{
	//~ Instance fields --------------------------------------------------------

	protected boolean setUPCalledFirst;
	protected boolean setUpCalled;
	protected boolean tearDownCalled;
	protected boolean tearDownCalledLast;
	protected boolean testRun;
	protected boolean testRunCalledAfterSetup;

	//~ Constructors -----------------------------------------------------------

	/***************************************
	 * TF_TestCase constructor comment.
	 *
	 * @param name java.lang.String
	 */
	public TF_TestCase(String name)
	{
		super(name);
	}

	//~ Methods ----------------------------------------------------------------

	/***************************************
	 * Insert the method's description here. Creation date: (11/2/00 1:16:40
	 * PM)
	 *
	 * @return boolean
	 */
	public boolean isSetUPCalledFirst()
	{
		return setUPCalledFirst;
	}

	/***************************************
	 * DOCUMENT ME!
	 *
	 * @return DOCUMENT ME!
	 */
	public boolean getSetupCalled()
	{
		return setUpCalled;
	}

	/***************************************
	 * DOCUMENT ME!
	 *
	 * @return DOCUMENT ME!
	 */
	public boolean getTearDownCalled()
	{
		return tearDownCalled;
	}

	/***************************************
	 * Insert the method's description here. Creation date: (11/2/00 1:16:40
	 * PM)
	 *
	 * @return boolean
	 */
	public boolean isTearDownCalledLast()
	{
		return tearDownCalledLast;
	}

	/***************************************
	 * DOCUMENT ME!
	 *
	 * @return DOCUMENT ME!
	 */
	public boolean getTestRun()
	{
		return testRun;
	}

	/***************************************
	 * Insert the method's description here. Creation date: (11/2/00 1:16:40
	 * PM)
	 *
	 * @return boolean
	 */
	public boolean isTestRunCalledAfterSetup()
	{
		return testRunCalledAfterSetup;
	}

	/***************************************
	 * Gets the name of the test case.
	 *
	 * @return DOCUMENT ME!
	 */
	public Test suite()
	{
		return new TestSuite(new TF_TestCase("").getClass(),
							 new String[] { "testOne" });
	}

	/***************************************
	 * DOCUMENT ME!
	 */
	public void testOne()
	{
		testRun = true;

		if (setUpCalled && !tearDownCalled)
			testRunCalledAfterSetup = true;
	}

	/***************************************
	 * DOCUMENT ME!
	 */
	protected void setUp()
	{
		setUpCalled = true;

		if (!testRun && !tearDownCalled)
			setUPCalledFirst = true;
	}

	/***************************************
	 * runTest method comment.
	 */
	protected void runTest() throws Throwable
	{
		if (getName().equals("testOne"))
			testOne();
		else
			throw new RuntimeException("You don't have a method called " +
									   getName());
	}

	/***************************************
	 * DOCUMENT ME!
	 */
	protected void tearDown()
	{
		tearDownCalled = true;

		if (setUpCalled && testRun)
			tearDownCalledLast = true;
	}
}
