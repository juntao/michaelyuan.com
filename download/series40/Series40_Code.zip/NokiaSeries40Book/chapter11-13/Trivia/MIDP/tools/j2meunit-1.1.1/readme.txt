J2MEUnit 1.1.1
Last Revision: 20.10.2003 - Elmar Sonnenschein (eso@users.sf.net)
Written in and for Java 2 Micro Edition (J2ME)
Hosted by Sourceforge at http://j2meunit.sourceforge.net

-----------------------------------------------------------------------

BACKGROUND

J2MEUnit is a simple unit test framework for small devices running
Java 2 Micro Edition. It is a port from JUnit, a testing framework
for Java, developed by Kent Beck and Erich Gamma. 

J2MEUnit is open source and distributed unter the Common Public
License. The license text can be found in the source code distribution
of J2MEUnit or at the website of the the Open Source Initiative
(http://www.opensource.org).

For further information please have a look at the documentation that
is part of the sourcecode distribution and which can be downloaded 
from the project page at Sourceforge (http://j2meunit.sourceforge.net).

-----------------------------------------------------------------------

CHANGES

Version 1.1.1
Some minor bugs fixed

Version 1.1
Optimized for easier usage in the non-reflection environment of J2ME

Version 1.0
Original version from RoleModel Software