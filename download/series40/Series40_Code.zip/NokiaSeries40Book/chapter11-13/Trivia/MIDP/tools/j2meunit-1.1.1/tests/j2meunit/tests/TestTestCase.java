//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
// This file is part of J2MEUnit, a Java 2 Micro Edition unit testing framework.
//
// J2MEUnit is free software distributed under the Common Public License (CPL).
// It may be redistributed and/or modified under the terms of the CPL. You 
// should have received a copy of the license along with J2MEUnit. It is also 
// available from the website of the Open Source Initiative at 
// http://www.opensource.org.
//
// J2MEUnit is distributed in the hope that it will be useful, but WITHOUT ANY 
// WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS 
// FOR A PARTICULAR PURPOSE.
//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
package j2meunit.tests;

import j2meunit.framework.*;

public class TestTestCase extends TestCase
{
	protected TF_TestCase testTestCase;
/**
 * NullEnumerationTest constructor comment.
 * @param name java.lang.String
 */
public TestTestCase() 
{

}
/**
 * Override to run the test and assert its state.
 * @exception Throwable if any exception is thrown
 */
protected void runTest() throws java.lang.Throwable {
	if (getName().equals("testSetupCalled"))
		testSetupCalled();
	else if (getName().equals("testTearDownCalled"))
		testTearDownCalled();
	else if (getName().equals("testTestRan"))
		testTestRan();
}
protected void setUp()
{
	testTestCase = new TF_TestCase("testOne");
	testTestCase.run();
}
/**
 * suite method comment.
 */
public j2meunit.framework.Test suite() {
	return new TestSuite(new TestTestCase().getClass(), new String[] {"testSetupCalled", "testTearDownCalled", "testTestRan"});
}
protected void tearDown()
{
	testTestCase = null;
}

public void testSetupCalled()
{ 
	assertTrue("Setup should have been called.", testTestCase.getSetupCalled());
	assertTrue("Setup should have been called first", testTestCase.isSetUPCalledFirst());
}

public void testTearDownCalled()
{ 
	assertTrue("tearDown should have been called.", testTestCase.getTearDownCalled());
	assertTrue("tearDown should have been called last", testTestCase.isTearDownCalledLast());	
}

public void testTestRan()
{ 
	assertTrue("The test should have been run.", testTestCase.getTestRun());
	assertTrue("test should have been called after setup", testTestCase.isTestRunCalledAfterSetup());	
}
}
