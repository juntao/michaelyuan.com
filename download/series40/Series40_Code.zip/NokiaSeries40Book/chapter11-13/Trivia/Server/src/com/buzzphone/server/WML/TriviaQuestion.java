package com.buzzphone.server.WML;

import java.sql.*;

/**
 * Created by IntelliJ IDEA.
 * User: juntao
 * Date: Jun 26, 2003
 * Time: 4:04:58 AM
 * To change this template use Options | File Templates.
 */
public class TriviaQuestion {

  public String questionId;
  public String question;
  public String [] choices;

  public TriviaQuestion (String id) {
    questionId = id;
    Connection conn= null;
    Statement stmt= null;
    ResultSet rs = null;

    try {
      Class.forName(TriviaHelper.className);
      conn =
        DriverManager.getConnection (TriviaHelper.jdbcURL, "sa", "");
      conn.setAutoCommit(true);
      stmt = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,
                                  ResultSet.CONCUR_READ_ONLY);
      rs = stmt.executeQuery("select question from Questions " + "" +
                             "where id=" + questionId);
      rs.next();
      question = rs.getString(1);

      rs = stmt.executeQuery("select choice from Choices " +
          "where questionId=" + questionId + " order by choiceId ASC");
      int size = 0;
      while (rs.next()) size++;
      choices = new String[size];
      rs.beforeFirst();
      for (int i = 0; i < size; i++) {
        rs.next();
        choices[i] = rs.getString(1);
      }

    } catch (Exception e) {
      e.printStackTrace();
    } finally {
      try {
        if (rs != null ) rs.close();
        if (stmt != null) stmt.close();
        if (conn != null) conn.close();
      } catch (Exception ee) {}
    }
  }

}
