package com.buzzphone.server.Google;

import com.google.soap.search.*;

public class GoogleUtil {

  private static String encoding = "UTF-8";

  // Returns a list of URLs
  public static String [] search (String key,
     String keywords, int maxResults) throws Exception {
    GoogleSearch search = new GoogleSearch();
    search.setKey(key);
    search.setMaxResults(maxResults);
    search.setQueryString(keywords);
    GoogleSearchResult result = search.doSearch();
    GoogleSearchResultElement [] elements =
        result.getResultElements();
    String [] ret = new String [elements.length];
    for (int i = 0; i < elements.length; i++) {
      ret[i] = elements[i].getURL();
    }
    return ret;
  }

  // Get the base64 decoded google cache
  public static String getCache (String key,
                       String url) throws Exception {
    GoogleSearch search = new GoogleSearch();
    search.setKey(key);
    search.setOutputEncoding (encoding);
    return new String (search.doGetCachedPage(url),
                       encoding);
  }

  public static String getSpellSugg (String key,
                       String word) throws Exception {
    GoogleSearch search = new GoogleSearch();
    search.setKey(key);
    return search.doSpellingSuggestion(word);
  }

}
