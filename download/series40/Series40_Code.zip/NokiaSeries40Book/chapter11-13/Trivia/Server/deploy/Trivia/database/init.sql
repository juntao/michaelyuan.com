create table Questions (id integer identity, question varchar(4096), category varchar(8), answerId integer, hasImage integer, hasMusic integer, answerHint varchar(4096), sendAnswer integer);
create table Choices (id integer identity, questionId integer, choiceId integer, choice varchar(4096));
create table History (ts bigint, correctNum integer, wrongNum integer, time bigint);
insert into History (ts, correctNum, wrongNum, time) values ('-1', '-1', '-1', '-1');
