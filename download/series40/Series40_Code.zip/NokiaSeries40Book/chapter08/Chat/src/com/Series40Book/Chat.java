package com.Series40Book;

import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;

public class Chat extends MIDlet {

  public static Display display;
  public static Sender sender;
  public static Inbox inbox;
  public static InboxViewer viewer;
  private static Chat controller;

  public static String url;

  public Chat () {
    display = Display.getDisplay(this);
    controller = this;
  }

  protected void startApp () {

    sender = new SenderImpl ();
    inbox = new InboxAsyncImpl ();
    sender.setPort (
             controller.getAppProperty("smsPort"));

    try {
      inbox.setupListener (
              controller.getAppProperty("smsPort"));
    } catch (Exception e) {
      // do nothing
    }

    viewer = new InboxViewer ();
    try {
      viewer.setStatus (inbox.firstMessage());
    } catch (Exception e) {
      e.printStackTrace ();
      viewer.setStatus ("Error in opening inbox");
    }
    display.setCurrent(viewer);

  }

  protected void pauseApp () {
    // Do nothing
  }

  protected void destroyApp (boolean unconditional) {
    // Do nothing
  }

  public static void exit () throws Exception {
    inbox.cleanUp ();
    controller.destroyApp (true);
    controller.notifyDestroyed ();
  }

//  public static void firstMessage () throws Exception {
//    viewer.setStatus (inbox.firstMessage());
//    display.setCurrent(viewer);
//  }

  public static void nextMessage ()
                          throws Exception {
    viewer.setStatus (inbox.nextMessage());
    display.setCurrent(viewer);
  }

  public static void deleteMessage ()
                                 throws Exception {
    inbox.deleteMessage ();
    viewer.setStatus (inbox.nextMessage());
    display.setCurrent(viewer);
  }


  public static void processNewMessage ()
                          throws Exception {
    // If the user is reading an existing
    // message, do not interrupt
    if (inbox.isBoxEmpty()) {
      // Show the new message on viewer
      viewer.setStatus(inbox.nextMessage());

      // Update display only if in message
      // browsing mode
      if (viewer == display.getCurrent()) {
        display.setCurrent (viewer);
      }
    }
  }

  public static void showSMSComposer(InboxViewer parent) {
    SMSComposer composer = new SMSComposer ();
    composer.setStatus (parent);
    display.setCurrent(composer);
  }

  public static void sendMessage (String addr,
                                  String mesg) {
    SendWorker worker = new SendWorker (addr, mesg);
    Thread t = new Thread (worker);
    t.start ();
  }
}

class SendWorker implements Runnable {

  private String addr, mesg;

  public SendWorker (String a, String m) {
    addr = a;
    mesg = m;
  }

  public void run () {
    try {
      Chat.sender.send(addr, mesg);
      Alert a = new Alert ("Success",
                           "Message sent",
                           null, AlertType.INFO);
      Chat.display.setCurrent (a);

    } catch (Exception e) {
      e.printStackTrace ();
      Alert a = new Alert ("Error",
                           "Message failed",
                           null, AlertType.ERROR);
      Chat.display.setCurrent (a);
    }
  }
}