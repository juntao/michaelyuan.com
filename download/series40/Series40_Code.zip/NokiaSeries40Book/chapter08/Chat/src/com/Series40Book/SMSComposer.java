package com.Series40Book;

import javax.microedition.lcdui.*;

public class SMSComposer extends Form
              implements CommandListener {

  private TextField phoneNumber, message;
  private Command go;
  private Command cancel;

  private InboxViewer parent;

  public SMSComposer () {
    super("Message");
    phoneNumber =
            new TextField("Phone Number", "", 20,
                                  TextField.NUMERIC);
    message = new TextField("Message", "", 128,
                                  TextField.ANY);
    append(phoneNumber);
    append(message);

    go = new Command("GO", Command.OK, 1);
    cancel = new Command("Cancel", Command.CANCEL, 1);
    addCommand(go);
    addCommand(cancel);
    setCommandListener(this);
  }

  // Construct the UI
  public void setStatus (InboxViewer p) {
    parent = p;
  }

  public void commandAction(Command c, Displayable s) {
    try {
      if (c == go) {
        Chat.sendMessage(phoneNumber.getString(),
                              message.getString());
      } else if (c == cancel) {
        // The SMSStatusUI's back button returns to
        // the InboxUI screen
        Chat.display.setCurrent(parent);
      }
    } catch (Exception e) {
      e.printStackTrace();
    }
  }
}
