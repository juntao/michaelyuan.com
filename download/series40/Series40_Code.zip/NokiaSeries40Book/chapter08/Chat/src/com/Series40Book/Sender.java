package com.Series40Book;

/**
 * Created by IntelliJ IDEA.
 */
public interface Sender {

  public void setPort (String port);
  public void send (String addr, String mesg) throws Exception;

}
