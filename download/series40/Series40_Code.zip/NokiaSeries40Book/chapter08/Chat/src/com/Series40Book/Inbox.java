package com.Series40Book;

public interface Inbox {

  public boolean isBoxEmpty ();
  
  public void setupListener (String port) throws Exception;
  public String firstMessage () throws Exception;
  public String nextMessage () throws Exception;
  public void deleteMessage () throws Exception;
  public void cleanUp () throws Exception;

}
