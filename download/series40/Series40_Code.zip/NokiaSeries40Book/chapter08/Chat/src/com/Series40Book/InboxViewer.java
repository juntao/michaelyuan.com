package com.Series40Book;

import javax.microedition.lcdui.*;

public class InboxViewer extends Form
            implements CommandListener {

  private Command next;
  private Command delete;
  private Command exit;
  private Command sendSMS;

  public InboxViewer () {
    super("Message");
    next = new Command("Next", Command.SCREEN, 1);
    delete = new Command("Delete", Command.SCREEN, 1);
    exit = new Command("Exit", Command.SCREEN, 2);
    sendSMS = new Command("Send SMS", Command.SCREEN, 1);


    addCommand(sendSMS);
    addCommand(next);
    addCommand(delete);
    addCommand(exit);

    setCommandListener(this);
  }

  // Construct the UI
  //
  // TODO: add incoming phone numbers
  public void setStatus (String mesg) {

    try {
      // Delete the old message
      delete (0);
    } catch (Exception e) {
      System.out.println("The form is new");
    }

    if (mesg == null || "".equals(mesg)) {
      append("No message");
    } else {
      append(mesg);
    }
  }

  public void commandAction(Command c, Displayable s) {
    try {
      if (c == next) {
        Chat.nextMessage();
      } else if (c == delete) {
        Chat.deleteMessage();
      } else if (c == exit) {
        Chat.exit();
      } else if (c == sendSMS) {
        Chat.showSMSComposer(this);
      }
    } catch (Exception e) {
      e.printStackTrace();
    }
  }
}
