import java.util.*;
import java.io.*;
import javax.microedition.io.*;
import javax.bluetooth.*;

public class BTConnection implements DiscoveryListener{

	//use long (128-bit) uuid, up to 32 hex characters
	public final static UUID CHAPTER10_UUID = new UUID("12345678901234567890123456789012", false);
	private static StreamConnectionNotifier m_server = null;

	private static LocalDevice m_localDevice;
	private static DiscoveryAgent m_discoveryAgent;
	private static Vector m_remoteDevices;
	private static Vector m_Connections;

	public BTConnection() {
	}

	private void registerService() {
		System.out.println("registerService()");
		try {
			BTServer server = new BTServer();
			server.init(m_Connections);
			Thread thread = new Thread( server );
			thread.start();

			//m_server = (StreamConnectionNotifier) Connector.open(
			//	"btspp://localhost:" + CHAPTER10_UUID.toString() +
			//	";name=Chapter10Example");
		}
		catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	public void init() {
		System.out.println("init()");
		try {
			m_localDevice = LocalDevice.getLocalDevice();
			m_localDevice.setDiscoverable(DiscoveryAgent.GIAC);
		}
		catch(BluetoothStateException ex) {
			ex.printStackTrace();
		}
		m_discoveryAgent = null;
		m_remoteDevices = null;
		m_Connections = new Vector();
		registerService();
	}

	public void find() {
		System.out.println("find()");
		try {
			m_discoveryAgent = m_localDevice.getDiscoveryAgent();
			m_remoteDevices = new Vector();
			m_discoveryAgent.startInquiry(DiscoveryAgent.GIAC, this);
		}
		catch(Exception ex) {
			ex.printStackTrace();
		}
	}

	//DiscoveryListener interface
	public void deviceDiscovered(RemoteDevice remoteDevice,
								 DeviceClass deviceClass) {
		try {
			System.out.println("deviceDiscovered " + remoteDevice.getFriendlyName(false));
		}
		catch (IOException ex) {
			ex.printStackTrace();
		}
		m_remoteDevices.addElement(remoteDevice);
	}

	//Found all devices, so start searching for services
	//DiscoveryListener interface
	public void inquiryCompleted(int int0) {
		System.out.println("FOUND " + m_remoteDevices.size() + " DEVICES.");

		for (int idx = m_remoteDevices.size()-1; idx >= 0; --idx) {
			RemoteDevice remoteDevice = (RemoteDevice)m_remoteDevices.elementAt(idx);
			try {
				int transactionId =
					m_discoveryAgent.searchServices(
								null,  // attributes
								new UUID[] {CHAPTER10_UUID},
								remoteDevice,
								this);
			}
			catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	//DiscoveryListener interface
	public void servicesDiscovered(int int0, ServiceRecord[] serviceRecordArray) {
		for (int idx=serviceRecordArray.length-1; idx >= 0; --idx) {
			String sURL = serviceRecordArray[idx].getConnectionURL(0, false);
			System.out.println(" serviceDiscovered at " + sURL);

			StreamConnection conn = null;
			try {
				conn = (StreamConnection) Connector.open(sURL);
			}
			catch (IOException ex) {
				ex.printStackTrace();
			}
			m_Connections.addElement(conn);

		}
	}

	//DiscoveryListener interface
	public void serviceSearchCompleted(int int0, int int1) {
		System.out.println("MADE " + m_Connections.size() + " CONNECTIONS.");
	}
}
