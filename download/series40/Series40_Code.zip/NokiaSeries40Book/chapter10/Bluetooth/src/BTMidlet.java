import javax.microedition.midlet.*;
import javax.microedition.lcdui.*;

public class BTMidlet extends MIDlet implements CommandListener
{
	public static BTMidlet m_midlet;
	private static Display m_display;

	public BTConnection m_btconn;

	public BTMidlet()
	{
	}

	protected void startApp() throws MIDletStateChangeException {
		m_midlet = this; //save for getMidlet()
		if (m_display == null) {
			m_display = Display.getDisplay(this);
//			m_display.setCurrent(m_canvas);
		}
		if (m_btconn == null) {
			m_btconn = new BTConnection();
			m_btconn.init();
			m_btconn.find();
		}
	}

	protected void pauseApp() {
	}

	protected void destroyApp(boolean unconditional) throws MIDletStateChangeException {
	}

	public void exit() {
		try {
			destroyApp(true);
		}
		catch (Exception e) {
		}
		notifyDestroyed();
		m_midlet = null;
		m_display = null;
	}

	public void commandAction(Command c, Displayable d)
	{
	}
}

