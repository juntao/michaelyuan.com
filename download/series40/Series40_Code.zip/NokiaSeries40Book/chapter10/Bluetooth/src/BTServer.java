import java.util.*;
import java.io.*;
import javax.microedition.io.*;

public class BTServer implements Runnable {
	static boolean m_done;
	static private StreamConnectionNotifier m_notifier;
	static private Vector m_Connections;

    public BTServer() {
    }

	public void init(Vector connections) {
		m_done = false;
		m_Connections = connections;
		try
		{
			m_notifier = (StreamConnectionNotifier)Connector.open(
				"btspp://localhost:" + BTConnection.CHAPTER10_UUID.toString() +
				";name=Chapter10Example");
		}
		catch (Exception ex) {
			ex.printStackTrace();
		}
	}

	public void run() {
		StreamConnection conn = null;
		while( !m_done)
		{
			try {
				//block until connect (StreamConnectionNotifier interface)
				conn = m_notifier.acceptAndOpen();

				if (!m_Connections.contains(conn)) {
					System.out.println("ACCEPTED NEW CONNECTION");
				}
			}
			catch (IOException ex) {
				ex.printStackTrace();

				if (conn != null) {
					try {
						conn.close();
					}
					catch (IOException ex2) {
					}
				}
			}
		}
	} //run
}