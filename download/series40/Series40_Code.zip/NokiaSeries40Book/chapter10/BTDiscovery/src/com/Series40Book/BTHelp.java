package com.Series40Book;

import javax.microedition.lcdui.*;
import javax.bluetooth.*;


public class BTHelp extends Form implements CommandListener{

  private BTDiscovery midlet;
  private BTUtil btutil;

  private Command back;
  private Command services;

  public BTHelp(BTDiscovery midlet, BTUtil btutil) {

    super("Help");
    this.midlet  = midlet;
    this.btutil = btutil;

    back = new Command ("Back", Command.BACK,1);
    addCommand (back);
    setCommandListener( this );

    displayhelp();
  }

  public void commandAction(Command c, Displayable d) {
    if (c == back) {
      midlet.display.setCurrent(midlet.infoForm);
    }
  }


  public void displayhelp()
  {
    this.append("Bluetooth discovery. This demo displays the Bluetooth parameters of the local and remote" +
                " devices. Just select either the local device or run a remote device discovery with an" +
                " optional service discovery for a specific device. Remember that for some devices you" +
                " need to switch on Bluetooth first.");

  }

}
